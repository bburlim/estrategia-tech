# Validação de Classificação de Eventos — 01/2026 (v2)

**Legenda:**
- **% certeza**: confiança do engine na classificação
- **Split**: fração do evento alocada a este produto (eventos multi-produto)
- **Validado**: classificação confirmada pelo usuário

---

## CT-e — 100 topics — 249,096,109 eventos efetivos (1 semana)

*Inclui 11 eventos multi-produto com split proporcional por volume.*

| Event Topic | Count bruto | Split | Count efetivo | % produto | % certeza | Observação |
|---|---|---|---|---|---|---|
| NOTIFICACAO_DOCS_CARGA_RECEBIDA | 31,653,190 | 100.0% | 31,642,235 | 12.7% | 100% | Multi: CT-e+MDF-e |
| STATUS_CTE_SHOPEE_ATUALIZADO | 23,302,942 | 100% | 23,302,942 | 9.4% | 100% | Produto explícito no nome do evento |
| CTE_SHOPEE_CONSULTADA | 23,302,942 | 100% | 23,302,942 | 9.4% | 100% | Produto explícito no nome do evento |
| CONSULTA_CTE_SHOPEE_RECEBIDA | 23,294,962 | 100% | 23,294,962 | 9.4% | 100% | Produto explícito no nome do evento |
| SHOPEE_ON_FLEET_FIRST_MILE_TRIP_ORDER_RECEBIDA | 16,395,164 | 100% | 16,395,164 | 6.6% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_ON_FLEET_FIRST_MILE_TRIP_ORDER_TRACKING_NUMBER_CONSULTADO | 16,395,141 | 100% | 16,395,141 | 6.6% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_ON_FLEET_FIRST_MILE_TRIP_ORDER_ATUALIZADO | 16,395,131 | 100% | 16,395,131 | 6.6% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| EMISSAO_CTE_CARGA_RECEBIDA | 11,766,173 | 100% | 11,766,173 | 4.7% | 100% | Produto explícito no nome do evento |
| STATUS_DOCUMENTO_CARGA_ATUALIZADO | 11,758,420 | 99.9% | 11,742,845 | 4.7% | 100% | Multi: CT-e+NFS-e |
| CTE_RECEBIDO | 11,714,433 | 100% | 11,714,433 | 4.7% | 100% | Produto explícito no nome do evento |
| CTE_ASSINADO | 11,713,828 | 100% | 11,713,828 | 4.7% | 100% | Produto explícito no nome do evento |
| CTE_AUTORIZADO | 9,691,439 | 100% | 9,691,439 | 3.9% | 100% | Produto explícito no nome do evento |
| SHOPEE_LH_TRIP_CONSULTA_TN_RECEBIDA | 5,064,249 | 100% | 5,064,249 | 2.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_LH_TRIP_TN_CONSULTADO | 5,064,222 | 100% | 5,064,222 | 2.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_LH_TRIP_TN_STATUS_ATUALIZADO | 5,064,134 | 100% | 5,064,134 | 2.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| TODOS_DOCUMENTOS_CARGA_PROCESSADOS | 4,173,780 | 99.9% | 4,168,251 | 1.7% | 100% | Multi: CT-e+NFS-e |
| CONSULTA_ITEM_LINE_HAUL_SOLICITADO | 4,122,186 | 100.0% | 4,120,759 | 1.7% | 100% | Multi: CT-e+MDF-e |
| HU_CONSULTADO | 3,537,195 | 100.0% | 3,535,971 | 1.4% | 100% | Multi: CT-e+MDF-e |
| CONSULTA_HU_SOLICITADA | 3,537,195 | 100.0% | 3,535,971 | 1.4% | 100% | Multi: CT-e+MDF-e |
| CTE_AUTORIZADA_IMPORTADA | 2,651,771 | 100% | 2,651,771 | 1.1% | 100% | Produto explícito no nome do evento |
| DOCUMENT_ROUTE_REDISPATCH_MELI_CONSULTADO | 2,430,896 | 100.0% | 2,430,055 | 1.0% | 100% | Multi: CT-e+MDF-e |
| CTE_REJEITADO | 1,912,289 | 100% | 1,912,289 | 0.8% | 100% | Produto explícito no nome do evento |
| WEBHOOK_NOTIFICADO | 10,164,853 | 12.7% | 1,291,534 | 0.5% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| INTEGRACAO_DOCUMENTO_INICIADA | 9,711,951 | 12.7% | 1,233,989 | 0.5% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| DOC_CTE_RECEBIDO | 402,961 | 100% | 402,961 | 0.2% | 100% | Produto explícito no nome do evento |
| AVERBACAO_SOLICITADA | 289,929 | 100% | 289,929 | 0.1% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| AVERBACAO_AUTORIZADA | 287,544 | 100% | 287,544 | 0.1% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| EMISSAO_AVERBACAO_CARGA_RECEBIDA | 223,470 | 100% | 223,470 | 0.1% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| SOLICITACAO_CONSULTA_DFE_CTE_RECEBIDO | 80,438 | 100% | 80,438 | 0.0% | 100% | Produto explícito no nome do evento |
| AVERBACAO_AVULSA_RECEBIDA | 66,450 | 100% | 66,450 | 0.0% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| CONSULTA_DFE_CTE_EXECUTADA | 60,151 | 100% | 60,151 | 0.0% | 100% | Produto explícito no nome do evento |
| RECEBIMENTO_CTE_AUTORIZADA | 39,301 | 100% | 39,301 | 0.0% | 100% | Produto explícito no nome do evento |
| ROUTE_REDISPATCH_MELI_CONSULTADA | 28,548 | 100.0% | 28,538 | 0.0% | 100% | Multi: CT-e+MDF-e |
| SHOPEE_ON_FLEET_FIRST_MILE_TRIP_RECEBIDA | 19,695 | 100% | 19,695 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| UPLOAD_CTE_RECEBIDO_API | 16,164 | 100% | 16,164 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_CANCELAMENTO_RECEBIDO | 11,447 | 100% | 11,447 | 0.0% | 100% | Produto explícito no nome do evento |
| DOCUMENTO_CTE_UNIDOCS_CONSULTADO | 10,879 | 100% | 10,879 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_CANCELADO | 10,223 | 100% | 10,223 | 0.0% | 100% | Produto explícito no nome do evento |
| SHOPEE_ON_FLEET_FIRST_MILE_TRIP_EMISSAO_SOLICITADA | 10,039 | 100% | 10,039 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| CIOT_ENCERRAMENTO_SOLICITADO | 9,006 | 100% | 9,006 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CONSULTA_CTE_UNIDOCS_EXECUTADA | 8,149 | 100% | 8,149 | 0.0% | 100% | Produto explícito no nome do evento |
| DOCUMENTOS_CTE_UNIDOCS_RECEBIDO | 8,147 | 100% | 8,147 | 0.0% | 100% | Produto explícito no nome do evento |
| EMISSAO_CIOT_CARGA_RECEBIDA | 6,711 | 100% | 6,711 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| SOLICITACAO_CIOT_RECEBIDA | 6,247 | 100% | 6,247 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| DOC_CIOT_RECEBIDO | 6,241 | 100% | 6,241 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CIOT_ENCERRADO | 5,785 | 100% | 5,785 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CIOT_AUTORIZADO | 5,405 | 100% | 5,405 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| SOLICITACAO_DOC_CTE_COMPLEMENTAR_RECEBIDO | 5,348 | 100% | 5,348 | 0.0% | 100% | Produto explícito no nome do evento |
| AVERBACAO_REJEITADA | 5,309 | 100% | 5,309 | 0.0% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| SHOPEE_LH_TRIP_RECEBIDA | 4,927 | 100% | 4,927 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_LH_TRIP_CARGA_RECEBIDA | 4,925 | 100% | 4,925 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_LH_TRIP_CONSULTA_ORDERS_RECEBIDA | 4,380 | 100% | 4,380 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| CIOT_PROCESSAMENTO_SOLICITADO | 3,132 | 100% | 3,132 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CONSULTA_ROTAS_LINE_HAUL_MELI_RECEBIDA | 3,026 | 100% | 3,026 | 0.0% | 80% | Line haul é transporte — validado como CT-e+MDF-e pelo usuário |
| CIOT_ENCERRAMENTO_REJEITADO | 2,961 | 100% | 2,961 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CONSULTA_ROUTE_REDISPATCH_MELI_SOLICITADA | 2,956 | 100.0% | 2,955 | 0.0% | 100% | Multi: CT-e+MDF-e |
| CARGA_MELI_LINE_HAUL_SALVA | 2,604 | 100% | 2,604 | 0.0% | 80% | Line haul é transporte — validado como CT-e+MDF-e pelo usuário |
| EDICAO_CIOT_SOLICITADA | 2,079 | 100% | 2,079 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CTE_AUTORIZADO_NOTIFICADO_SENIOR | 1,566 | 100% | 1,566 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_CANCELAMENTO_REJEITADO | 1,194 | 100% | 1,194 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_EMISSAO_PERSISTIDO | 1,098 | 100% | 1,098 | 0.0% | 100% | Produto explícito no nome do evento |
| PEDIDO_MULTICTE_RECEBIDO | 846 | 100% | 846 | 0.0% | 100% | Produto explícito no nome do evento |
| CIOT_REJEITADO | 789 | 100% | 789 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CANCELAMENTO_AVERBACAO_SOLICITADO | 752 | 100% | 752 | 0.0% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| AVERBACAO_CANCELADA | 715 | 100% | 715 | 0.0% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| AJUSTE_FINANCEIRO_CIOT_SOLICITADO | 706 | 100% | 706 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| AJUSTE_FINANCEIRO_CIOT_HOMOLOGADO | 697 | 100% | 697 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CARGA_MULTICTE_GERADA | 626 | 100% | 626 | 0.0% | 100% | Produto explícito no nome do evento |
| CARGA_MULTICTE_ATUALIZADA | 602 | 100% | 602 | 0.0% | 100% | Produto explícito no nome do evento |
| RECEBIMENTO_CANCELAMENTO_CTE | 364 | 100% | 364 | 0.0% | 100% | Produto explícito no nome do evento |
| CIOT_INSUANCE_FROM_RECEIVED_DOCUMENT_REQUESTED | 195 | 100% | 195 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| STATUS_CONCILIACAO_CTE_RECEBIDO | 171 | 100% | 171 | 0.0% | 100% | Produto explícito no nome do evento |
| CIOT_INCONSISTENTE | 123 | 100% | 123 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CIOT_CANCELAMENTO_SOLICITADO | 71 | 100% | 71 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| PROCESSAMENTO_CHUNK_IMPORTACAO_CIOT_SOLICITADO | 67 | 100% | 67 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| PROCESSAMENTO_CHUNK_IMPORTACAO_CIOT_CONCLUIDO | 64 | 100% | 64 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CIOT_CANCELADO | 63 | 100% | 63 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| IMPORTACAO_CIOT_SOLICITADA | 61 | 100% | 61 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CANCELAMENTO_CTE_SENIOR_EXECUTADO | 48 | 100% | 48 | 0.0% | 100% | Produto explícito no nome do evento |
| SHOPEE_ON_FLEET_LAST_MILE_TRIP_ORDER_ATUALIZADO | 36 | 100% | 36 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_ON_FLEET_LAST_MILE_TRIP_ORDER_TRACKING_NUMBER_CONSULTA_SOLICITADA | 36 | 100% | 36 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_ON_FLEET_LAST_MILE_TRIP_ORDER_TRACKING_NUMBER_CONSULTADO | 36 | 100% | 36 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| CIOT_ADIANTAMENTO_VIAGEM_HOMOLOGADO | 31 | 100% | 31 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CIOT_ADIANTAMENTO_VIAGEM_SOLICITADO | 31 | 100% | 31 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| AVERBACAO_CANCELAMENTO_REJEITADO | 25 | 100% | 25 | 0.0% | 95% | Averbação é exclusiva de CT-e (seguro de carga) |
| CIOT_COMPLEMENTAR_SOLICITADO | 24 | 100% | 24 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| INTEGRACAO_MULTICTE_ERRO | 17 | 100% | 17 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_CCE_RECEBIDO | 11 | 100% | 11 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_CCE_REGISTRADO | 10 | 100% | 10 | 0.0% | 100% | Produto explícito no nome do evento |
| AJUSTE_FINANCEIRO_CIOT_REJEITADO | 9 | 100% | 9 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| CIOT_CANCELAMENTO_REJEITADO | 7 | 100% | 7 | 0.0% | 95% | CIOT é exclusivo de CT-e |
| RECEBIMENTO_CCE_CTE | 6 | 100% | 6 | 0.0% | 80% | Contexto forte de CT-e |
| CTE_EVENTO_DESACORDO_RECEBIDO | 5 | 100% | 5 | 0.0% | 100% | Produto explícito no nome do evento |
| SHOPEE_ON_FLEET_LAST_MILE_TRIP_EMISSAO_SOLICITADA | 4 | 100% | 4 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_ON_FLEET_LAST_MILE_TRIP_ORDER_STATUS_ATUALIZADO | 2 | 100% | 2 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| SHOPEE_ON_FLEET_LAST_MILE_TRIP_RECEBIDA | 2 | 100% | 2 | 0.0% | 85% | Integração Shopee logística — fortemente ligada a CT-e, mas nome genérico |
| CTE_CCE_RECEBIDO_REJEITADO | 1 | 100% | 1 | 0.0% | 100% | Produto explícito no nome do evento |
| CTE_EVENTO_DESACORDO_REJEITADO | 1 | 100% | 1 | 0.0% | 100% | Produto explícito no nome do evento |
| ENVIO_CONTRATO_CIOT_POR_EMAIL_SOLICITADO | 1 | 100% | 1 | 0.0% | 80% | Contexto forte de CT-e |
| COMPLEMENTO_CIOT_PERSISTIDO | 1 | 100% | 1 | 0.0% | 80% | Contexto forte de CT-e |

---

## GNRE — 54 topics — 13,354,301 eventos efetivos (1 semana)

*Inclui 2 eventos multi-produto com split proporcional por volume.*

| Event Topic | Count bruto | Split | Count efetivo | % produto | % certeza | Observação |
|---|---|---|---|---|---|---|
| GNRE_EMISSAO_SITUACAO_ATUALIZADA | 2,567,333 | 100% | 2,567,333 | 19.2% | 100% | Produto explícito no nome do evento |
| GNRE_RECEBIDO | 1,530,555 | 100% | 1,530,555 | 11.5% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_PERSISTIDO | 1,525,666 | 100% | 1,525,666 | 11.4% | 100% | Produto explícito no nome do evento |
| INPUT_GNRE_RECEBIDO | 1,492,093 | 100% | 1,492,093 | 11.2% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_CANCELADO | 883,345 | 100% | 883,345 | 6.6% | 100% | Produto explícito no nome do evento |
| GNRE_VERIFICACAO_FLUXO_APROVACAO_SOLICITADO | 671,924 | 100% | 671,924 | 5.0% | 100% | Produto explícito no nome do evento |
| FITBANK_WEBHOOK_NOTIFICADO | 630,597 | 100% | 630,597 | 4.7% | 95% | FitBank é provedor exclusivo de pagamento GNRE |
| PDF_GNRE_GERADO | 348,863 | 100% | 348,863 | 2.6% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_VALORES_ATUALIZADOS_PELO_SEFAZ | 346,437 | 100% | 346,437 | 2.6% | 100% | Produto explícito no nome do evento |
| CHUNK_REEMISSAO_GNRE_RECEBIDA | 346,408 | 100% | 346,408 | 2.6% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_LIQUIDACAO_SOLICITADA | 337,157 | 100% | 337,157 | 2.5% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_PAGAMENTO_PERSISTIDO | 318,313 | 100% | 318,313 | 2.4% | 100% | Produto explícito no nome do evento |
| GNRE_CONSULTA_INFOS_PAGAMENTO_FITBANK_MONTADO | 315,639 | 100% | 315,639 | 2.4% | 100% | Produto explícito no nome do evento |
| GNRE_PAGAMENTO_FITBANK_APROVADO | 315,222 | 100% | 315,222 | 2.4% | 100% | Produto explícito no nome do evento |
| GNRE_PAGAMENTO_FITBANK_MONTADO | 315,117 | 100% | 315,117 | 2.4% | 100% | Produto explícito no nome do evento |
| GNRE_INFOS_PAGAMENTO_FITBANK_CONSULTADO | 315,054 | 100% | 315,054 | 2.4% | 100% | Produto explícito no nome do evento |
| GNRE_PAGAMENTO_FITBANK_ENVIADO | 314,936 | 100% | 314,936 | 2.4% | 100% | Produto explícito no nome do evento |
| GNRE_AM_NFE_NAO_ENCONTRADA | 282,283 | 100% | 282,283 | 2.1% | 100% | Produto explícito no nome do evento |
| GNRE_LOTE_ENVIADO | 154,283 | 100% | 154,283 | 1.2% | 100% | Produto explícito no nome do evento |
| GNRE_REJEITADA | 85,459 | 100% | 85,459 | 0.6% | 100% | Produto explícito no nome do evento |
| WEBHOOK_NOTIFICADO | 10,164,853 | 0.5% | 52,783 | 0.4% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| INTEGRACAO_DOCUMENTO_INICIADA | 9,711,951 | 0.5% | 50,431 | 0.4% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| GNRE_AM_AUTORIZADO | 38,140 | 100% | 38,140 | 0.3% | 100% | Produto explícito no nome do evento |
| DOC_GNRE_RECEBIDO | 22,452 | 100% | 22,452 | 0.2% | 100% | Produto explícito no nome do evento |
| EMISSAO_GNRE_CARGA_RECEBIDA | 22,438 | 100% | 22,438 | 0.2% | 100% | Produto explícito no nome do evento |
| GNRE_AVULSA_RECEBIDA | 22,276 | 100% | 22,276 | 0.2% | 100% | Produto explícito no nome do evento |
| GNRE_AM_LOTE_FECHADO | 15,207 | 100% | 15,207 | 0.1% | 100% | Produto explícito no nome do evento |
| REPROCESSAMENTO_GNRE_SOLICITADO_EVENT | 15,189 | 100% | 15,189 | 0.1% | 100% | Produto explícito no nome do evento |
| GNRE_AM_REJEITADA | 6,226 | 100% | 6,226 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_PAGAMENTO_FAKE_APROVADO | 2,499 | 100% | 2,499 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_CONSOLIDADO_PERSISTIDO | 1,761 | 100% | 1,761 | 0.0% | 100% | Produto explícito no nome do evento |
| IMPORTACAO_AND_EMISSAO_GNRE_SHOPEE_POR_ESTADO_FINALIZADA | 1,706 | 100% | 1,706 | 0.0% | 100% | Produto explícito no nome do evento |
| IMPORTACAO_AND_EMISSAO_GNRE_SHOPEE_POR_ESTADO_INICIADA | 1,705 | 100% | 1,705 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_AVULSA_RECEBIDA_ERRO | 1,490 | 100% | 1,490 | 0.0% | 100% | Produto explícito no nome do evento |
| CONSULTA_CONFIGURACAO_UF_GNRE_SOLICITADA | 768 | 100% | 768 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_PROCESSA_XML_NFE_COM_ERROR | 401 | 100% | 401 | 0.0% | 100% | Produto explícito no nome do evento |
| JOB_IMPORTACAO_AND_EMISSAO_GNRE_SHOPEE_INICIADO | 341 | 100% | 341 | 0.0% | 100% | Produto explícito no nome do evento |
| OCR_GNRE_SOLICITADO | 230 | 100% | 230 | 0.0% | 100% | Produto explícito no nome do evento |
| BRADESCO_PAYMENT_INTEGRATION_REQUESTED | 213 | 100% | 213 | 0.0% | 95% | Pagamento Bradesco vinculado à GNRE |
| BRADESCO_PAYMENT_INTEGRATION_RESPONDED | 213 | 100% | 213 | 0.0% | 95% | Pagamento Bradesco vinculado à GNRE |
| GNRE_PAGAMENTO_BRADESCO_APROVADO | 208 | 100% | 208 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_ERRO_ENVIO_LOTE_PAGAMENTO | 191 | 100% | 191 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_PAGAMENTO_FITBANK_REPROVADO | 184 | 100% | 184 | 0.0% | 100% | Produto explícito no nome do evento |
| PDF_GNRE_ERRO | 162 | 100% | 162 | 0.0% | 100% | Produto explícito no nome do evento |
| CHUNK_COMPROVANTE_PAGAMENTO_GNRE_EM_MASSA_RECEBIDO | 140 | 100% | 140 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_CANCELAMENTO_SOLICITADO | 92 | 100% | 92 | 0.0% | 100% | Produto explícito no nome do evento |
| MIGRACAO_DADOS_OCR_GNRE_EM_MASSA_CHUNK_SOLICITADA | 54 | 100% | 54 | 0.0% | 100% | Produto explícito no nome do evento |
| OCR_GNRE_EXTRACAO_DADOS_ERRO | 37 | 100% | 37 | 0.0% | 100% | Produto explícito no nome do evento |
| MIGRACAO_DADOS_OCR_GNRE_EM_MASSA_CHUNK_FINALIZADA | 34 | 100% | 34 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_EM_MASSA_RECEBIDO | 15 | 100% | 15 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_EMISSAO_PROCESSA_XML_NFE_RECEBIDO | 14 | 100% | 14 | 0.0% | 100% | Produto explícito no nome do evento |
| IMPORTACAO_COMPROVANTE_PAGAMENTO_GNRE_EM_MASSA_RECEBIDA | 6 | 100% | 6 | 0.0% | 100% | Produto explícito no nome do evento |
| CHUNKS_COMPROVANTE_PAGAMENTO_GNRE_EM_MASSA_PERSISTIDOS | 6 | 100% | 6 | 0.0% | 100% | Produto explícito no nome do evento |
| GNRE_PAGAMENTO_BRADESCO_REPROVADO | 5 | 100% | 5 | 0.0% | 100% | Produto explícito no nome do evento |

---

## NFS-e — 28 topics — 1,424,409 eventos efetivos (1 semana)

*Inclui 4 eventos multi-produto com split proporcional por volume.*

| Event Topic | Count bruto | Split | Count efetivo | % produto | % certeza | Observação |
|---|---|---|---|---|---|---|
| SHOPEE_NFSE_PAYLOAD_RECEBIDO | 157,832 | 100% | 157,832 | 11.1% | 100% | Produto explícito no nome do evento |
| SHOPEE_NFSE_RECEBIDA | 156,015 | 100% | 156,015 | 11.0% | 100% | Produto explícito no nome do evento |
| NFSE_RECEBIDA | 142,160 | 100% | 142,160 | 10.0% | 100% | Produto explícito no nome do evento |
| DOC_NFSE_RECEBIDO | 142,147 | 100% | 142,147 | 10.0% | 100% | Produto explícito no nome do evento |
| NFSE_PERSISTIDA | 142,147 | 100% | 142,147 | 10.0% | 100% | Produto explícito no nome do evento |
| EMISSAO_NFSE_CARGA_RECEBIDA | 134,791 | 100% | 134,791 | 9.5% | 100% | Produto explícito no nome do evento |
| RPS_CRIADO | 130,261 | 100% | 130,261 | 9.1% | 95% | RPS é exclusivo de NFS-e |
| NFSE_NEGADA_SISTEMICAMENTE | 124,936 | 100% | 124,936 | 8.8% | 100% | Produto explícito no nome do evento |
| SHOPEE_NFSE_ERROR | 91,021 | 100% | 91,021 | 6.4% | 100% | Produto explícito no nome do evento |
| EMPRESA_BROKER_NFSE_SINCRONIZADA | 51,560 | 100% | 51,560 | 3.6% | 100% | Produto explícito no nome do evento |
| RETORNO_NFSE_RECEBIDO | 18,643 | 100% | 18,643 | 1.3% | 100% | Produto explícito no nome do evento |
| RETORNO_BROKER_NFSE_RECEBIDO | 18,623 | 100% | 18,623 | 1.3% | 100% | Produto explícito no nome do evento |
| PAYLOAD_BROKER_NFSE_RECEBIDO | 18,621 | 100% | 18,621 | 1.3% | 100% | Produto explícito no nome do evento |
| NFSE_STATUS_FINAL_WEBHOOK_SOLICITADO | 17,364 | 100% | 17,364 | 1.2% | 100% | Produto explícito no nome do evento |
| NFSE_ENVIADA | 17,195 | 100% | 17,195 | 1.2% | 100% | Produto explícito no nome do evento |
| STATUS_DOCUMENTO_CARGA_ATUALIZADO | 11,758,420 | 0.1% | 15,575 | 1.1% | 100% | Multi: CT-e+NFS-e |
| NFSE_REJEITADA | 11,314 | 100% | 11,314 | 0.8% | 100% | Produto explícito no nome do evento |
| DOCUMENTO_NFSE_UNIDOCS_CONSULTADO | 10,881 | 100% | 10,881 | 0.8% | 100% | Produto explícito no nome do evento |
| NFSE_AUTORIZADA | 6,047 | 100% | 6,047 | 0.4% | 100% | Produto explícito no nome do evento |
| TODOS_DOCUMENTOS_CARGA_PROCESSADOS | 4,173,780 | 0.1% | 5,529 | 0.4% | 100% | Multi: CT-e+NFS-e |
| RPS_APROVADO | 3,767 | 100% | 3,767 | 0.3% | 95% | RPS é exclusivo de NFS-e |
| RPS_REIJEITADO | 2,379 | 100% | 2,379 | 0.2% | 95% | RPS é exclusivo de NFS-e |
| RPS_EMISSAO_NFSE_SOLICITADA | 1,938 | 100% | 1,938 | 0.1% | 100% | Produto explícito no nome do evento |
| WEBHOOK_NOTIFICADO | 10,164,853 | 0.0% | 1,713 | 0.1% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| INTEGRACAO_DOCUMENTO_INICIADA | 9,711,951 | 0.0% | 1,637 | 0.1% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| EMISSAO_NFSE_API_RECEBIDA | 230 | 100% | 230 | 0.0% | 100% | Produto explícito no nome do evento |
| NFSE_CANCELADA | 61 | 100% | 61 | 0.0% | 100% | Produto explícito no nome do evento |
| CERTIFICADO_INTEGRADO_BROKER_NFSE | 22 | 100% | 22 | 0.0% | 100% | Produto explícito no nome do evento |

---

## NF-e — 49 topics — 57,176,300 eventos efetivos (1 semana)

*Inclui 2 eventos multi-produto com split proporcional por volume.*

| Event Topic | Count bruto | Split | Count efetivo | % produto | % certeza | Observação |
|---|---|---|---|---|---|---|
| WEBHOOK_NOTIFICADO | 10,164,853 | 86.8% | 8,818,376 | 15.4% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| INTEGRACAO_DOCUMENTO_INICIADA | 9,711,951 | 86.8% | 8,425,467 | 14.7% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| RECEBIMENTO_NFE_AUTORIZADA | 4,734,468 | 100% | 4,734,468 | 8.3% | 100% | Produto explícito no nome do evento |
| NFE_AUTORIZADA_RECEBIDA_PERSISTIDA | 4,731,517 | 100% | 4,731,517 | 8.3% | 100% | Produto explícito no nome do evento |
| DOCUMENTO_MELI_CONSULTADO | 4,560,854 | 100% | 4,560,854 | 8.0% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| CONSULTA_DOCUMENTO_MELI_RECEBIDA | 4,496,365 | 100% | 4,496,365 | 7.9% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| STATUS_CARGA_MELI_DOCUMENTO_ITEM_ATUALIZADO | 4,496,331 | 100% | 4,496,331 | 7.9% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| CONSULTA_NFE_MELI_RECEBIDA | 4,143,703 | 100% | 4,143,703 | 7.2% | 100% | Produto explícito no nome do evento |
| STATUS_CARGA_MELI_HU_SHIPMENT_ATUALIZADO | 4,122,188 | 100% | 4,122,188 | 7.2% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| ITENS_MELI_PERSISTIDOS | 4,116,616 | 100% | 4,116,616 | 7.2% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| STATUS_CARGA_MELI_HU_ATUALIZADO | 3,537,943 | 100% | 3,537,943 | 6.2% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| DOCUMENTO_DFE_NFE_RECEBIDO | 675,381 | 100% | 675,381 | 1.2% | 100% | Produto explícito no nome do evento |
| SOLICITACAO_CONSULTA_CH_NFE_DFE_RECEBIDO | 78,513 | 100% | 78,513 | 0.1% | 100% | Produto explícito no nome do evento |
| CONSULTA_DCE_MELI_RECEBIDA | 63,671 | 100% | 63,671 | 0.1% | 75% | Evento MELI sem produto explícito — provável NF-e |
| UPLOAD_NFE_RECEBIDO_API | 54,125 | 100% | 54,125 | 0.1% | 100% | Produto explícito no nome do evento |
| DFE_NFE_CONSULTADA | 37,385 | 100% | 37,385 | 0.1% | 100% | Produto explícito no nome do evento |
| CONFERENCIA_GERAL_CARGA_RECEBIDA | 16,243 | 100% | 16,243 | 0.0% | 80% | Contexto forte de NF-e |
| RECEBIMENTO_NFE_AUTORIZADA_IMPORTADA | 14,698 | 100% | 14,698 | 0.0% | 100% | Produto explícito no nome do evento |
| ITENS_ARQUIVO_AMAZON_PERSISTIDOS | 7,916 | 100% | 7,916 | 0.0% | 85% | Emissões Amazon são NF-e |
| PERSISTENCIA_DE_CHUNK_DE_NFE_REALIZADA | 7,868 | 100% | 7,868 | 0.0% | 100% | Produto explícito no nome do evento |
| STATUS_ARQUIVO_AMAZON_ATUALIZADO | 7,380 | 100% | 7,380 | 0.0% | 85% | Emissões Amazon são NF-e |
| NENHUM_ITEM_FISCAL_RETORNADO_MELI | 5,609 | 100% | 5,609 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| STATUS_CARGA_MELI_ATUALIZADO | 5,234 | 100% | 5,234 | 0.0% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| CONFERENCIA_MELI_RECEBIDA | 2,647 | 100% | 2,647 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| MELI_IMPORTACAO_NFES_FISCAL_INFO_CONSULTADO | 2,025 | 100% | 2,025 | 0.0% | 80% | Contexto MELI importação NF-e |
| MELI_IMPORTACAO_NFES_HU_CONSULTADO | 1,799 | 100% | 1,799 | 0.0% | 80% | Contexto MELI importação NF-e |
| COOKIE_NOT_FOUND_MELI | 1,767 | 100% | 1,767 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| ARQUIVO_AMAZON_RECEBIDO | 1,759 | 100% | 1,759 | 0.0% | 85% | Emissões Amazon são NF-e |
| ARQUIVO_AMAZON_ENVOLVIDOS_INFERIDOS | 1,740 | 100% | 1,740 | 0.0% | 85% | Emissões Amazon são NF-e |
| ARQUIVO_AMAZON_RECEBIDO_API | 1,201 | 100% | 1,201 | 0.0% | 85% | Emissões Amazon são NF-e |
| EMISSAO_AMAZON_RECEBIDA | 1,078 | 100% | 1,078 | 0.0% | 85% | Emissões Amazon são NF-e |
| ARQUIVO_AMAZON_CANCELADO | 817 | 100% | 817 | 0.0% | 85% | Emissões Amazon são NF-e |
| CONSULTA_ROTAS_FIRST_MILE_MELI_RECEBIDA | 718 | 100% | 718 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| IMPORTACAO_ARQUIVOS_AMAZON_INICIADA | 669 | 100% | 669 | 0.0% | 85% | Emissões Amazon são NF-e |
| CONSULTA_ROTAS_LAST_MILE_MELI_RECEBIDA | 660 | 100% | 660 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| NFE_AUTORIZADA_RECEBIDA_ITENS_PERSISTIDOS | 634 | 100% | 634 | 0.0% | 100% | Produto explícito no nome do evento |
| NFE_RECEBIMENTO_ATUALIZADA | 239 | 100% | 239 | 0.0% | 100% | Produto explícito no nome do evento |
| CANCELAMENTO_CARGA_MELI_SOLICITADO | 122 | 100% | 122 | 0.0% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| NFE_RECEBIMENTO_REMOVIDA | 111 | 100% | 111 | 0.0% | 100% | Produto explícito no nome do evento |
| SOLICITA_CANCELAMENTO_DOCUMENTO_VINCULADO_AMAZON | 91 | 100% | 91 | 0.0% | 85% | Emissões Amazon são NF-e |
| CARGA_CONFERENCIA_ERRO | 88 | 100% | 88 | 0.0% | 80% | Contexto forte de NF-e |
| CANCELAMENTO_DOCUMENTO_VINCULADO_MELI_SOLICITADO | 79 | 100% | 79 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| CONSULTA_VEICULOS_MELI_RECEBIDA | 60 | 100% | 60 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| CONSULTA_MOTORISTAS_MELI_RECEBIDA | 60 | 100% | 60 | 0.0% | 75% | Evento MELI sem produto explícito — provável NF-e |
| EMISSAO_AMAZON_AGRUPADA_RECEBIDA | 43 | 100% | 43 | 0.0% | 85% | Emissões Amazon são NF-e |
| CARGA_MELI_RECEBIDA | 36 | 100% | 36 | 0.0% | 85% | Integração MELI — documentos fiscais MELI são NF-e |
| NFE_RECEBIMENTO_REMOCAO_SOLICITADA | 3 | 100% | 3 | 0.0% | 100% | Produto explícito no nome do evento |
| MELI_IMPORTACAO_NFES_BY_ROUTE_AND_FACILITY_ID_SOLICITADA | 2 | 100% | 2 | 0.0% | 80% | Contexto MELI importação NF-e |
| MELI_IMPORTACAO_NFES_HUS_CONSULTADOS | 1 | 100% | 1 | 0.0% | 80% | Contexto MELI importação NF-e |

---

## MDF-e — 35 topics — 276,658 eventos efetivos (1 semana)

*Inclui 9 eventos multi-produto com split proporcional por volume.*

| Event Topic | Count bruto | Split | Count efetivo | % produto | % certeza | Observação |
|---|---|---|---|---|---|---|
| EMISSAO_MDFE_CARGA_RECEBIDA | 30,921 | 100% | 30,921 | 11.2% | 100% | Produto explícito no nome do evento |
| MDFE_ENCERRAMENTO_RECEBIDO | 27,234 | 100% | 27,234 | 9.8% | 100% | Produto explícito no nome do evento |
| DOC_MDFE_RECEBIDO | 26,471 | 100% | 26,471 | 9.6% | 100% | Produto explícito no nome do evento |
| MDFE_RECEBIDO | 26,423 | 100% | 26,423 | 9.6% | 100% | Produto explícito no nome do evento |
| MDFE_ASSINADO | 26,411 | 100% | 26,411 | 9.5% | 100% | Produto explícito no nome do evento |
| MDFE_ENCERRADO | 26,251 | 100% | 26,251 | 9.5% | 100% | Produto explícito no nome do evento |
| MDFE_AUTORIZADO | 21,544 | 100% | 21,544 | 7.8% | 100% | Produto explícito no nome do evento |
| MDFE_XML_PERSISTIDO | 21,537 | 100% | 21,537 | 7.8% | 100% | Produto explícito no nome do evento |
| MDFE_SOLICITACAO_ENCERRAMENTO_RECEBIDO | 16,955 | 100% | 16,955 | 6.1% | 100% | Produto explícito no nome do evento |
| NOTIFICACAO_DOCS_CARGA_RECEBIDA | 31,653,190 | 0.0% | 10,955 | 4.0% | 100% | Multi: CT-e+MDF-e |
| EMISSAO_AVULSA_API_MDFE_RECEBIDA | 9,812 | 100% | 9,812 | 3.5% | 100% | Produto explícito no nome do evento |
| SHOPEE_ON_FLEET_FIRST_MILE_EMITE_MDFE_SOLICITADA | 9,703 | 100% | 9,703 | 3.5% | 100% | Produto explícito no nome do evento |
| MDFE_ENCERRAMENTO_DUPLICIDADE | 5,358 | 100% | 5,358 | 1.9% | 100% | Produto explícito no nome do evento |
| MDFE_REJEITADO | 4,912 | 100% | 4,912 | 1.8% | 100% | Produto explícito no nome do evento |
| EMISSAO_MDFE_ENCERRAMENTO_CARGA_RECEBIDA | 2,636 | 100% | 2,636 | 1.0% | 100% | Produto explícito no nome do evento |
| CONSULTA_ITEM_LINE_HAUL_SOLICITADO | 4,122,186 | 0.0% | 1,427 | 0.5% | 100% | Multi: CT-e+MDF-e |
| SOLICITACAO_CTE_COMPLEMENTAR_BY_ENCERRAMENTO_MDFE_RECEBIDO | 1,227 | 100% | 1,227 | 0.4% | 100% | Produto explícito no nome do evento |
| HU_CONSULTADO | 3,537,195 | 0.0% | 1,224 | 0.4% | 100% | Multi: CT-e+MDF-e |
| CONSULTA_HU_SOLICITADA | 3,537,195 | 0.0% | 1,224 | 0.4% | 100% | Multi: CT-e+MDF-e |
| DOCUMENT_ROUTE_REDISPATCH_MELI_CONSULTADO | 2,430,896 | 0.0% | 841 | 0.3% | 100% | Multi: CT-e+MDF-e |
| MDFE_ENCERRAMENTO_REJEITADO | 736 | 100% | 736 | 0.3% | 100% | Produto explícito no nome do evento |
| MDFE_AVULSO_RECEBIDO | 708 | 100% | 708 | 0.3% | 100% | Produto explícito no nome do evento |
| MDFE_CANCELAMENTO_RECEBIDO | 499 | 100% | 499 | 0.2% | 100% | Produto explícito no nome do evento |
| WEBHOOK_NOTIFICADO | 10,164,853 | 0.0% | 447 | 0.2% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| INTEGRACAO_DOCUMENTO_INICIADA | 9,711,951 | 0.0% | 427 | 0.2% | 100% | Multi: CT-e+GNRE+NFS-e+NF-e+MDF-e |
| MDFE_CANCELADO | 302 | 100% | 302 | 0.1% | 100% | Produto explícito no nome do evento |
| MDFE_CANCELAMENTO_REJEITADO | 201 | 100% | 201 | 0.1% | 100% | Produto explícito no nome do evento |
| CIOT_ENCERRAMENTO_MDFE_SOLICITADO | 165 | 100% | 165 | 0.1% | 100% | Produto explícito no nome do evento |
| GNRE_CONSOLIDADO_MDFE_RECEBIDO | 47 | 100% | 47 | 0.0% | 100% | Produto explícito no nome do evento |
| ARQUIVO_AMAZON_MDFE_AVULSO_SOLICITADO | 41 | 100% | 41 | 0.0% | 100% | Produto explícito no nome do evento |
| ROUTE_REDISPATCH_MELI_CONSULTADA | 28,548 | 0.0% | 10 | 0.0% | 100% | Multi: CT-e+MDF-e |
| MDFE_ENCERRAMENTO_AUTOMATICO | 4 | 100% | 4 | 0.0% | 100% | Produto explícito no nome do evento |
| MDFE_INCLUSAO_CONDUTOR_REJEITADO | 2 | 100% | 2 | 0.0% | 100% | Produto explícito no nome do evento |
| CONSULTA_ROUTE_REDISPATCH_MELI_SOLICITADA | 2,956 | 0.0% | 1 | 0.0% | 100% | Multi: CT-e+MDF-e |
| MDFE_INCLUSAO_CONDUTOR_RECEBIDO | 1 | 100% | 1 | 0.0% | 100% | Produto explícito no nome do evento |

---

## Platform — 186 topics — 7,910,850 eventos efetivos (1 semana)

| Event Topic | Count bruto | Split | Count efetivo | % produto | % certeza | Observação |
|---|---|---|---|---|---|---|
| OCORRENCIA_SHOPEE_FIRST_MILE_RECEBIDA | 1,234,371 | 100% | 1,234,371 | 15.6% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| ERROR | 1,031,379 | 100% | 1,031,379 | 13.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| OCORRENCIA_CRIADA | 851,239 | 100% | 851,239 | 10.8% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| OCORRENCIA_CONFIRMADA | 851,219 | 100% | 851,219 | 10.8% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| STARTED_RETRY | 803,074 | 100% | 803,074 | 10.2% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| EMPRESA_SALVA | 450,338 | 100% | 450,338 | 5.7% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| OCORRENCIA_SHOPEE_LAST_MILE_RECEBIDA | 441,618 | 100% | 441,618 | 5.6% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| RENOTIFICA_DOCUMENTOS_EMITIDOS_CARGA | 339,592 | 100% | 339,592 | 4.3% | 75% | Evento genérico sem produto identificável no nome |
| LIMITE_RETRY_EXCEDIDO | 277,725 | 100% | 277,725 | 3.5% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| PROCESSAMENTO_CARGA_ERROR | 243,995 | 100% | 243,995 | 3.1% | 75% | Evento genérico sem produto identificável no nome |
| SHOPEE_TRIP_WEBHOOK_RECEBIDA | 239,117 | 100% | 239,117 | 3.0% | 75% | Evento genérico sem produto identificável no nome |
| OCORRENCIA_SHOPEE_LINE_HAUL_RECEBIDA | 232,290 | 100% | 232,290 | 2.9% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| NEW_TUPLA | 120,747 | 100% | 120,747 | 1.5% | 75% | Evento genérico sem produto identificável no nome |
| EMPRESA_CADASTRADA | 70,633 | 100% | 70,633 | 0.9% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| CARGA_RECEBIDA | 65,510 | 100% | 65,510 | 0.8% | 75% | Evento genérico sem produto identificável no nome |
| TARIFA_CARGA_CONSULTADA | 61,742 | 100% | 61,742 | 0.8% | 75% | Evento genérico sem produto identificável no nome |
| DOMINIO_WEBSERVICE_NOTIFICADO | 49,926 | 100% | 49,926 | 0.6% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_CONSULTA_DFE_RECEBIDO | 48,437 | 100% | 48,437 | 0.6% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_CONSOLIDADO_CARGA_ATUALIZADO | 46,452 | 100% | 46,452 | 0.6% | 75% | Evento genérico sem produto identificável no nome |
| NOTIFICACAO_CARGA_RECEBIDA | 45,198 | 100% | 45,198 | 0.6% | 75% | Evento genérico sem produto identificável no nome |
| INPUT_CAPA_RECEBIDO | 44,962 | 100% | 44,962 | 0.6% | 75% | Evento genérico sem produto identificável no nome |
| INTEGRACAO_DOCUMENTO_SUCCESSO | 39,239 | 100% | 39,239 | 0.5% | 75% | Evento genérico sem produto identificável no nome |
| WATCH_DOC_CARGA_STATUS | 36,980 | 100% | 36,980 | 0.5% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_CARGA_SHOPEE_ATUALIZADO | 33,504 | 100% | 33,504 | 0.4% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_CONSULTA_UNIDOCS_RECEBIDA | 24,941 | 100% | 24,941 | 0.3% | 75% | Evento genérico sem produto identificável no nome |
| OCORRENCIA_DOCUMENTO_APLICADO | 18,186 | 100% | 18,186 | 0.2% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| OBSERVACAO_RELATORIO_ALTERADA | 16,105 | 100% | 16,105 | 0.2% | 75% | Evento genérico sem produto identificável no nome |
| ARQUIVO_SHOPEE_AGUARDANDO_EMISSAO | 13,159 | 100% | 13,159 | 0.2% | 75% | Evento genérico sem produto identificável no nome |
| CHUNK_DOCUMENTO_CARGA_RECEBIDO | 10,577 | 100% | 10,577 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| EMAIL_ENVIADO | 10,255 | 100% | 10,255 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| CARGA_ARQUIVO_SHOPEE_RECEBIDA | 8,933 | 100% | 8,933 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| CARGA_SHOPEE_IDENTIFICADA | 8,932 | 100% | 8,932 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| VOTACAO_SOLICITADA_NO_FLUXO_APROVACAO | 7,411 | 100% | 7,411 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| ARQUIVO_SHOPEE_GERANDO_CARGA | 7,377 | 100% | 7,377 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| ARQUIVO_SHOPEE_CONCLUIDO | 6,798 | 100% | 6,798 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_OCORRENCIA_DOCUMENTO_APLICADO_REFERENCIADO_SHOPEE_RECEBIDO | 6,273 | 100% | 6,273 | 0.1% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| NOTIFICATION_CREATED | 6,132 | 100% | 6,132 | 0.1% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| CONTA_RECEBER_PERSISTIDA | 5,507 | 100% | 5,507 | 0.1% | 85% | Evento financeiro/fiscal transversal |
| INPUT_LAYOUT_DINAMICO_GENERICO_RECEBIDO | 5,475 | 100% | 5,475 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| VEICULO_SALVO | 4,554 | 100% | 4,554 | 0.1% | 90% | Cadastro de entidade logística — transversal a CT-e |
| CONTRATO_SERVICO_PERSISTIDO_ATUALIZA_STATUS | 4,082 | 100% | 4,082 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| EMISSAO_CONTRATO_SERVICO_CARGA_RECEBIDA | 4,039 | 100% | 4,039 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| DOC_CONTRATO_SERVICO_RECEBIDO | 4,037 | 100% | 4,037 | 0.1% | 75% | Evento genérico sem produto identificável no nome |
| NOTIFICACAO_OCORRENCIA_NATURA_LOTE_CRIADO | 3,851 | 100% | 3,851 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| NOTIFICACAO_OCORRENCIA_NATURA_LOTE_SUCESSO | 3,825 | 100% | 3,825 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| STATUS_CARGA_MAGALU_ATUALIZADO | 3,770 | 100% | 3,770 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ABBI_WEBHOOK_ORDER_STATUS_CHANGE | 3,647 | 100% | 3,647 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CRIAR_OCORRENCIA_IMPORTACAO_RECEBIDA | 2,767 | 100% | 2,767 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| MOTORISTA_CADASTRADO | 2,668 | 100% | 2,668 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| CERTIFICADO_ALTERADO | 2,612 | 100% | 2,612 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| IMPORTACAO_MANUAL_LINE_HAUL_RECEBIDA | 2,604 | 100% | 2,604 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| MOTORISTA_ALTERADO | 2,574 | 100% | 2,574 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| RESUMO_DFE_RECEBIDO | 2,416 | 100% | 2,416 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CERTIFICADO_EXCLUIDO_POR_SUBSTITUICAO | 2,362 | 100% | 2,362 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| CONSULTA_DFE_SUSPENSA | 2,300 | 100% | 2,300 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| EMAIL_RECEBIDO | 2,181 | 100% | 2,181 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| NATURA_WEBSERVICE_NOTIFICADO | 1,992 | 100% | 1,992 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CRIAR_PEDIDO_IMPORTACAO_RECEBIDO | 1,894 | 100% | 1,894 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_CARGA_MAGALU_API_INICIADA | 1,888 | 100% | 1,888 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PROCESSAMENTO_CHUNK_CARGA_MAGALU_FINALIZADO | 1,885 | 100% | 1,885 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PROCESSAMENTO_CHUNK_CARGA_MAGALU_INICIADO | 1,885 | 100% | 1,885 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PERSISTENCIA_CARGA_MAGALU_API_FINALIZADA | 1,885 | 100% | 1,885 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ALGUEM_VOTOU_NO_FLUXO_APROVACAO | 1,627 | 100% | 1,627 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PROPRIETARIO_CADASTRADO | 1,530 | 100% | 1,530 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| SOLICITACAO_OCORRENCIA_EMITIDA | 1,429 | 100% | 1,429 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| SOLICITACAO_OCORRENCIA_APROVADA | 1,425 | 100% | 1,425 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| RELATORIO_SOLICITADO | 1,330 | 100% | 1,330 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| REPORT_DONE | 1,291 | 100% | 1,291 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| SOLICITACAO_OCORRENCIA_CRIADA | 1,266 | 100% | 1,266 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| INTEGRACAO_PROPRIETARIO_ERROR | 1,209 | 100% | 1,209 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CHUNK_LEITURA_EMAIL_RECEBIDA | 1,089 | 100% | 1,089 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| INTEGRACAO_VEICULO_ERROR | 986 | 100% | 986 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| LAYOUT_DINAMICO_CARREGADO | 929 | 100% | 929 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| REGIAO_CRIADA | 825 | 100% | 825 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_OCORRENCIA_FLUXO_APROVACAO_RECEBIDA | 784 | 100% | 784 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| OCORRENCIA_FLUXO_APROVACAO_APROVADO | 784 | 100% | 784 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| NOTIFICACAO_OCORRENCIA_NATURA_LOTE_FALHA | 753 | 100% | 753 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| ROTA_AVULSA_DOCUMENTO_VINCULADO | 699 | 100% | 699 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ARQUIVO_SHOPEE_RECEBIDO | 634 | 100% | 634 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_EDI_JOB_INICIADO | 617 | 100% | 617 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ALTERACAO_STATUS_FORMACAO_CARGA | 526 | 100% | 526 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| INTEGRACAO_MOTORISTA_SUCCESS | 520 | 100% | 520 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITA_CANCELAMENTO_DOCUMENTO_VINCULADO_SHOPEE | 475 | 100% | 475 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CARGA_ERROR | 461 | 100% | 461 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_CARGA_MAGALU_API_ERRO | 431 | 100% | 431 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ROTA_AVULSA_CRIADA | 429 | 100% | 429 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| INTEGRACAO_FATURA_SOLICITADA | 405 | 100% | 405 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| FATURA_CONTA_RECEBER_SOLICITADA | 400 | 100% | 400 | 0.0% | 85% | Evento financeiro/fiscal transversal |
| INTEGRACAO_VEICULO_SUCCESS | 393 | 100% | 393 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| FATURA_GERADA | 392 | 100% | 392 | 0.0% | 85% | Evento financeiro/fiscal transversal |
| INTEGRACAO_DOCUMENTO_ERRO | 376 | 100% | 376 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ICMS_SALVO | 316 | 100% | 316 | 0.0% | 85% | Evento financeiro/fiscal transversal |
| ERRO_AO_VOTAR_NO_FLUXO_APROVACAO | 281 | 100% | 281 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ORDEM_COLETA_CRIADA | 263 | 100% | 263 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CONTA_PAGAR_PERSISTIDA | 254 | 100% | 254 | 0.0% | 85% | Evento financeiro/fiscal transversal |
| SOLICITACOES_OCORRENCIA_CANCELAMENTO | 231 | 100% | 231 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ORDEM_COLETA_STATUS_ALTERADO | 228 | 100% | 228 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| TRANSPORTADORA_SELECIONADA_FORMACAO_CARGA | 222 | 100% | 222 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_VALE_PEDAGIO_RECEBIDO | 209 | 100% | 209 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| ARQUIVO_SHOPEE_CANCELADO | 209 | 100% | 209 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| DOC_VALE_PEDAGIO_RECEBIDO | 208 | 100% | 208 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| INTEGRACAO_MOTORISTA_ERROR | 204 | 100% | 204 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| INTEGRACAO_PROPRIETARIO_SUCCESS | 203 | 100% | 203 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| EMISSAO_VP_CARGA_RECEBIDA | 193 | 100% | 193 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CONCILIACAO_PERSISTIDA | 181 | 100% | 181 | 0.0% | 85% | Evento financeiro/fiscal transversal |
| NATURA_WEBSERVICE_NOTIFICADO_ERROR | 165 | 100% | 165 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_CONSOLIDADO_CARGA_INTEGRACAO_ABBIAMO | 150 | 100% | 150 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| VALE_PEDAGIO_COMPRADO | 137 | 100% | 137 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| SOLICITACAO_OCORRENCIA_HISTORICO_GERADO | 131 | 100% | 131 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| USUARIO_ALTERADO | 109 | 100% | 109 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| RESET_SENHA_SOLICITADO | 104 | 100% | 104 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| ROTA_VALE_PEDAGIO_ATUALIZADA | 98 | 100% | 98 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| ROTA_VALE_PEDAGIO_ATUALIZADA_INTEGRADA | 95 | 100% | 95 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| AGRUPAMENTO_ALTERADO | 93 | 100% | 93 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ERRO_NOTIFICACAO_SENIOR | 84 | 100% | 84 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| FECHAMENTO_NOTA_SENIOR_EXECUTADO | 79 | 100% | 79 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| REGIAO_ALTERADA | 73 | 100% | 73 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| DOC_GESTAO_RISCO_ATUALIZADA | 69 | 100% | 69 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| DOC_GESTAO_RISCO_ORDEM_COLETA_PERSISTIDO | 69 | 100% | 69 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_VALIDACAO_CONCILIACAO_ATUALIZADO | 55 | 100% | 55 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PARAMETRIZACAO_ATUALIZADA | 55 | 100% | 55 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_CONCILIACAO_ATUALIZADO | 54 | 100% | 54 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_INTEGRACAO_SENIOR | 54 | 100% | 54 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| STATUS_DOCUMENTO_ESPERADO_ATUALIZADO | 52 | 100% | 52 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PROCESSAMENTO_CARGA | 48 | 100% | 48 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| MOTORISTA_RODOBANK_CADASTRADO_RECEBIDO | 45 | 100% | 45 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| GRUPO_EMPRESA_ALTERADO | 41 | 100% | 41 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| VEICULO_CAVALO_RODOBANK_CADASTRADO_RECEBIDO | 41 | 100% | 41 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| EMISSAO_GESTAO_RISCO_ORDEM_COLETA_RECEBIDA | 41 | 100% | 41 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_MANUAL_FIRST_MILE_RECEBIDA | 36 | 100% | 36 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| GESTAO_RISCO_CODIGO_VIAGEM_ANEXADO | 36 | 100% | 36 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| VEICULO_REBOQUE_RODOBANK_CADASTRADO_RECEBIDO | 35 | 100% | 35 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| REPORT_PROCESSING_ERROR | 34 | 100% | 34 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| ORDEM_COLETA_ACAO_EMAIL_CONFIRMACAO_SOLICITADA | 29 | 100% | 29 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| LOTE_FORMACAO_CARGA_CRIADO | 28 | 100% | 28 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PROPRIETARIO_RODOBANK_CADASTRADO_RECEBIDO | 28 | 100% | 28 | 0.0% | 90% | Cadastro de entidade logística — transversal a CT-e |
| OCORRENCIA_EDITADA | 23 | 100% | 23 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| PRE_CADASTRO_EMPRESA_ENVIO_EMAIL_SOLICITADO | 22 | 100% | 22 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| IMPORTACAO_CONTA_RECEBER_POR_DOCUMENTO_RECEBIDA | 22 | 100% | 22 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CERTIFICADO_EXCLUIDO | 21 | 100% | 21 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| REQUESTE_VOTACAO_EM_MASSA_NO_FLUXO_APROVACAO | 20 | 100% | 20 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PERFIL_ALTERADO | 19 | 100% | 19 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| ORDEM_COLETA_DADOS_ALTERADOS | 18 | 100% | 18 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| OCORRENCIA_IMPORTACAO_DINAMICA_SOLICITADA | 15 | 100% | 15 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| CIENCIA_OPERACAO_HOMOLOGADA | 15 | 100% | 15 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| DOC_CONTRATO_SERVICO_INDEPENDENTE_RECEBIDO | 15 | 100% | 15 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| EMISSAO_CONTRATO_SERVICO_INDEPENDENTE_CARGA_RECEBIDA | 15 | 100% | 15 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PRE_CADASTRO_EMPRESA_UPLOAD_CERTIFICADO_REALIZADO | 15 | 100% | 15 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| VALE_PEDAGIO_AVULSO_SOLICITADO | 13 | 100% | 13 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| COMPONENTE_FRETE_SALVO | 13 | 100% | 13 | 0.0% | 85% | Evento financeiro/fiscal transversal |
| VALE_PEDAGIO_REJEITADO | 12 | 100% | 12 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| DOC_VALE_PEDAGIO_REJEITADO | 12 | 100% | 12 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| PRE_CADASTRO_EMPRESA_CONCLUIDO | 11 | 100% | 11 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| IMPORTACAO_PEDIDO_MASSA_RECEBIDA | 10 | 100% | 10 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_FORMACAO_CARGA_RECEBIDA | 9 | 100% | 9 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITA_GERACAO_FATURA | 9 | 100% | 9 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACOES_OCORRENCIA_EXCLUIDAS_EM_MASSA | 8 | 100% | 8 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| CONSULTA_PREFATURA_NATURA_SOLICITADO | 7 | 100% | 7 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITA_RECEBIMENTO_FATURA | 6 | 100% | 6 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ROTA_VALE_PEDAGIO_CADASTRADA | 6 | 100% | 6 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| CHUNK_IMPORTACAO_EMPRESA_EM_MASSA_RECEBIDO | 6 | 100% | 6 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PREFATURA_NATURA_CONSULTADA | 5 | 100% | 5 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACAO_OCORRENCIA_EM_MASSA | 5 | 100% | 5 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| ROTA_VALE_PEDAGIO_CADASTRADA_INTEGRADA | 4 | 100% | 4 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| OBSERVACAO_ALTERADA | 4 | 100% | 4 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_EMPRESA_EM_MASSA_SALVA | 4 | 100% | 4 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_EMPRESA_EM_MASSA_RECEBIDA | 4 | 100% | 4 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ROTA_VALE_PEDAGIO_NAO_INTEGRADA | 3 | 100% | 3 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| CORPORACAO_CADASTRADA | 3 | 100% | 3 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| SOLICITA_CANCELAMENTO_FATURA | 3 | 100% | 3 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| INTEGRACAO_FATURA_ERRO | 2 | 100% | 2 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| TENNANT_INICIADO | 2 | 100% | 2 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| CANCELAMENTO_GESTAO_RISCO_SOLICITADO | 2 | 100% | 2 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| USUARIO_TENNANT_GERADO | 2 | 100% | 2 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| INFO_TENNANT_GERADAS | 2 | 100% | 2 | 0.0% | 99% | Evento de sistema/cadastro — não pertence a produto fiscal |
| PARAMETRIZACOES_VALE_PEDAGIO_CRIADA | 2 | 100% | 2 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SOLICITACOES_OCORRENCIA_APROVADAS_EM_MASSA | 1 | 100% | 1 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| ROZ_STORAGE_REFERENCIA_ARQUIVO_DELETADO | 1 | 100% | 1 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| OCORRENCIA_FLUXO_APROVACAO_REPROVADO | 1 | 100% | 1 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| VALE_PEDAGIO_CANCELAMENTO_EFETUADO | 1 | 100% | 1 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |
| FALHA_CANCELAMENTO_GESTAO_RISCO | 1 | 100% | 1 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| PARAMETRIZACOES_VALE_PEDAGIO_ATUALIZADA | 1 | 100% | 1 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| IMPORTACAO_CONTA_PAGAR_POR_DOCUMENTO_RECEBIDA | 1 | 100% | 1 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| SUCESSO_CANCELAMENTO_GESTAO_RISCO | 1 | 100% | 1 | 0.0% | 75% | Evento genérico sem produto identificável no nome |
| OCORRENCIA_CANCELADA | 1 | 100% | 1 | 0.0% | 80% | Ocorrências são transversais — produto subjacente não identificável no nome |
| VALE_PEDAGIO_CANCELAMENTO_SOLICITADO | 1 | 100% | 1 | 0.0% | 80% | Vale pedágio ligado a CT-e mas registrado como entidade separada |

---

