# Relatório de Custo Unitário — 01/2026

**Data:** 2026-03-30
**Versão:** 2.1 (substituí v2.0 — classificação de eventos validada e corrigida)
**Período analisado:** janeiro de 2026
**Responsável:** engine custo_produto

---

## 1. Resumo executivo

### Objetivo
Calcular o custo unitário de cloud (Azure) por documento fiscal emitido ou processado na plataforma, para o período de janeiro de 2026, utilizando critério de rateio multi-componente baseado em consumo técnico real.

### Escopo
Produtos analisados: CT-e, GNRE, NFS-e, NF-e, MDF-e

### Conclusão principal

| Produto | Volume (docs/mês) | Custo cloud total (R$) | Custo unitário (R$/doc) |
|--------|-------------------|------------------------|------------------------|
| CT-e   | 294.137.725       | 60.470,11              | **0,0002056**          |
| GNRE   | 12.020.898        | 4.790,95               | **0,0003986**          |
| NFS-e  | 390.138           | 303,56                 | **0,0007781**          |
| NF-e   | 2.008.322.716     | 57.562,31              | **0,0000287**          |
| MDF-e  | 101.839           | 373,07                 | **0,0036633**          |
| **Total** | **2.314.973.316** | **123.500,00**      |                        |

**Destaques:**
- CT-e domina o custo de compute e storage — gera 74% dos eventos da plataforma
- NFS-e tem custo unitário alto por complexidade de processamento (brokers municipais, retentativas), apesar do baixo volume
- MDF-e tem maior custo unitário por ser produto de menor volume com arquivos relativamente grandes
- NF-e tem o menor custo unitário — beneficia-se fortemente de economia de escala
- **Esta análise cobre apenas custo de cloud. Custos diretos e demais indiretos não estão incluídos.**

---

## 2. Mudança em relação à versão anterior (v1.0)

A v1.0 usava um único critério PSC (Volume × KB) para todo o Azure. A v2.0 usa critério multi-componente.

| Produto | v1.0 PSC (R$/doc) | v2.0 Multi (R$/doc) | Variação |
|--------|-------------------|---------------------|---------|
| CT-e   | 0,0000736         | 0,0002056           | +179%   |
| GNRE   | 0,0016363         | 0,0003986           | -76%    |
| NFS-e  | 0,0000409         | 0,0007781           | +1.801% |
| NF-e   | 0,0000409         | 0,0000287           | -30%    |
| MDF-e  | —                 | 0,0036633           | novo    |

**Por que os números mudaram tanto:**
- O PSC (KB por arquivo) media bem storage/transferência, mas ignorava o custo de compute e banco
- CT-e e NFS-e geram muito mais eventos por documento do que KB sugeria
- GNRE tinha KB=200 inflando artificialmente seu custo — o processamento real é proporcional ao evento, não ao tamanho do arquivo
- NF-e tem 87% do volume, o que absorve a maior parte do custo de banco de dados

---

## 3. Método de custeio

### Classificação dos custos

- **Custo direto:** não utilizado nesta análise (decisão explícita)
- **Custo indireto:** Azure/Cloud total = R$ 123.500,00/mês

### Nota sobre o total de R$ 123.500

O export da Azure somou R$ 101.048,34. A diferença de R$ 22.451,66 (18,2%) corresponde a taxas e impostos incluídos na fatura. Os valores foram escalonados proporcionalmente (fator 1,2222) para refletir o custo real.

### Decomposição do Azure escalonado

| Componente | Valor (R$) | % | Critério de rateio |
|---|---|---|---|
| Compute (VMs, AKS) | 29.030,71 | 23,5% | % de eventos processados |
| Database (PostgreSQL) | 41.220,45 | 33,4% | % de volume de documentos |
| Storage | 32.369,24 | 26,2% | % de tamanho dos eventos (bytes) |
| Networking | 17.505,20 | 14,2% | % de tamanho dos eventos (bytes) |
| Platform (DevOps, Monitor) | 3.374,39 | 2,7% | % de volume de documentos |
| **Total** | **123.500,00** | **100%** | |

### Critérios de rateio por componente

| Componente | Critério | Justificativa |
|---|---|---|
| Compute | Eventos processados (count) | Proxy de CPU/processamento — mais eventos = mais compute |
| Storage | Tamanho dos eventos (bytes) | Proxy de dados armazenados e transferidos |
| Networking | Tamanho dos eventos (bytes) | Proxy de tráfego de rede |
| Database | Volume de documentos | Proxy de footprint no banco — sem dado de GB por produto disponível |
| Platform overhead | Volume de documentos | Distribuição flat, custos não atribuíveis diretamente |

Decisão formal registrada em: `.agents/decisions/2026-01-rateio-multi-criterio-cloud.md`

### Fonte dos eventos

- Arquivo: `grouped-jan-consolidated(Data).csv`
- Cobertura: 1 semana
- Extrapolação: ×4 para o mês completo
- Premissa: a semana disponível é representativa do mês

---

## 4. Dados de entrada

### Volume por produto

| Produto | Volume (docs/mês) | Fonte |
|--------|-------------------|-------|
| CT-e   | 294.137.725       | Planilha financeira |
| GNRE   | 12.020.898        | Planilha financeira |
| NFS-e  | 390.138           | Planilha financeira |
| NF-e   | 2.008.322.716     | Planilha financeira |
| MDF-e  | 101.839           | Planilha financeira |
| **Total** | **2.314.973.316** | |

### Custo indireto

| Tipo | Valor mensal (R$) | Fonte |
|------|------------------|-------|
| Azure/Cloud (total com taxas) | 123.500,00 | Planilha financeira |

### Distribuição de eventos por produto (extrapolado — mês estimado)

| Produto | % eventos | % tamanho (bytes) | % volume |
|--------|-----------|-------------------|---------|
| CT-e   | 77,5%     | 64,8%             | 12,7%   |
| GNRE   | 4,2%      | 6,7%              | 0,5%    |
| NFS-e  | 0,4%      | 0,3%              | 0,0%    |
| NF-e   | 17,8%     | 27,5%             | 86,8%   |
| MDF-e  | 0,1%      | 0,7%              | 0,0%    |

---

## 5. Resultado detalhado por produto

| Produto | Volume | Compute (R$) | Storage (R$) | Networking (R$) | Database (R$) | Platform (R$) | Total (R$) | Unit (R$/doc) |
|--------|--------|-------------|-------------|----------------|--------------|--------------|-----------|--------------|
| CT-e   | 294.137.725 | 22.504,86 | 20.962,57 | 11.336,51 | 5.237,42 | 428,75 | 60.470,11 | 0,0002056 |
| GNRE   | 12.020.898  | 1.206,51  | 2.176,06  | 1.176,81  | 214,04   | 17,52  | 4.790,95  | 0,0003986 |
| NFS-e  | 390.138     | 128,69    | 108,61    | 58,74     | 6,95     | 0,57   | 303,56    | 0,0007781 |
| NF-e   | 2.008.322.716 | 5.165,66 | 8.897,36 | 4.811,67 | 35.760,22 | 2.927,41 | 57.562,31 | 0,0000287 |
| MDF-e  | 101.839     | 25,00     | 224,63    | 121,48    | 1,81     | 0,15   | 373,07    | 0,0036633 |
| **Total** | **2.314.973.316** | **29.030,71** | **32.369,24** | **17.505,20** | **41.220,45** | **3.374,39** | **123.500,00** | |

### Validação cruzada
- Soma dos totais por produto: R$ 123.500,00 ✅
- Custo total ≥ custo direto (zero) para todos os produtos ✅
- Nenhum valor negativo ✅
- Nenhuma divisão por zero ✅

---

## 6. Análise dos resultados

### Principais drivers por produto

**CT-e** — dominado por compute e storage (55% do custo total da plataforma)
- 74% dos eventos com 12,7% do volume
- Muitos eventos por documento: emissão, assinatura, autorização, webhook, averbação, CIOT, integrações Shopee

**GNRE** — storage é o maior componente (45% do custo do produto)
- Arquivos grandes (200 KB) geram alto footprint de storage
- Processamento de pagamento (FitBank, Bradesco) contribui nos eventos

**NFS-e** — compute é o maior componente (44% do custo do produto)
- Complexidade de integração municipal (broker por cidade) gera retentativas e eventos extras
- Custo unitário elevado apesar do baixo volume

**NF-e** — banco de dados é o maior componente (65% do custo do produto)
- 87% do volume → absorve R$ 35.760 dos R$ 41.220 de PostgreSQL
- Custo de compute relativamente baixo: menor razão eventos/documento

**MDF-e** — storage é o maior componente (60% do custo do produto)
- Volume pequeno não dilui os custos fixos proporcionais
- Custo unitário mais alto da plataforma neste modelo

---

## 7. Premissas

1. Custo direto = R$ 0,00 — não incluído nesta análise por decisão explícita
2. Total Azure = R$ 123.500,00, sendo R$ 22.451,66 de taxas/impostos não detalhados no export
3. Eventos extrapolados de 1 semana × 4 — premissa de semana representativa do mês
4. Critério de rateio de banco de dados: por volume (sem dado de GB por produto disponível)
5. Eventos da categoria "Platform" (24% do total) distribuídos proporcionalmente entre os produtos
6. Mapeamento de event topics para produtos baseado em análise semântica dos nomes dos eventos

---

## 8. Limitações

- **Custo parcial:** apenas cloud. Custos diretos (provider fiscal, APIs, taxas bancárias GNRE) e demais indiretos (engenharia, suporte, monitoramento) não estão incluídos
- **Eventos de 1 semana:** extrapolação assume semana típica. Meses com pico (ex: dezembro) podem variar
- **Database por volume:** sem dado de GB por produto, o rateio do PostgreSQL por volume é uma aproximação. Com o dado de GB por cliente mapeado por produto, o resultado de NF-e (hoje dominante) poderia mudar
- **Platform events (24%):** eventos não atribuíveis diretamente a produto foram distribuídos proporcionalmente — simplificação metodológica
- **Taxas/impostos Azure:** R$ 22.451,66 distribuídos proporcionalmente ao custo líquido — podem ter distribuição diferente por tipo de serviço

---

## 9. Nível de confiança

**MÉDIA** para o custo de cloud multi-critério

- Volume e custo Azure: confirmados ✅
- Eventos: 1 semana extrapolada, não mês completo ⚠️
- Rateio de banco: proxy por volume, não por GB real ⚠️
- Mapeamento de eventos: semântico, pode haver imprecisão em topics genéricos ⚠️

---

## 10. Riscos

- Usar custo unitário cloud como custo total do produto — faltam componentes relevantes
- NFS-e e MDF-e com custo unitário alto podem pressionar pricing se não forem incluídos corretamente
- Variação sazonal nos eventos pode distorcer o rateio de compute/storage
- O rateio de banco favorece NF-e (menor por documento) por absorver o volume — se GB real for diferente, NF-e pode ficar mais caro

---

## 11. Recomendação de uso

- [x] Pode ser usado como referência operacional para o componente cloud
- [x] Usar com cautela para decisões de pricing — análise parcial
- [ ] Não usar como custo total até incluir custos diretos e demais indiretos

---

## 12. Próximos passos

1. Incluir custos diretos por produto (provider fiscal, APIs, taxas bancárias GNRE)
2. Incluir demais custos indiretos (engenharia, suporte, monitoramento)
3. Obter dados de GB por produto no banco para refinar o rateio do PostgreSQL
4. Obter eventos de um mês completo para eliminar a extrapolação
5. Revisão humana antes de uso em decisão de pricing

---

## 13. Observações finais

Esta versão (v2.0) substitui completamente a v1.0. O método multi-critério é metodologicamente superior ao PSC único e revela custos que o modelo anterior distorcia significativamente — especialmente NFS-e (subestimado em 22x) e CT-e (subestimado em 3x).
