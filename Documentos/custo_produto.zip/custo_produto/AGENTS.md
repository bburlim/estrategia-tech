# AGENTS.md

## Missão do projeto
Este repositório mantém um engine operacional para agentes no Claude Code com foco em levantar, validar, calcular e publicar o custo unitário direto, indireto e total de produtos fiscais operados pelo SaaS.

Os produtos atualmente no escopo são:

- CT-e
- GNRE
- NFS-e
- NF-e
- MDF-e

O objetivo do engine é produzir análises repetíveis, auditáveis e revisáveis por humanos, reduzindo ambiguidade metodológica e evitando decisões de custo baseadas em percepção informal.

## Papel dos agentes
Os agentes deste repositório devem atuar como operadores de processo, não como fonte arbitrária de opinião.

Responsabilidades esperadas:

1. receber o contexto mínimo da tarefa
2. identificar lacunas de dados e hipóteses
3. aplicar o método de custeio definido no repositório
4. separar claramente fatos, hipóteses, premissas e decisões
5. produzir saída estruturada pronta para revisão humana
6. registrar handoff curto para continuidade entre sessões
7. manter README e CHANGELOG atualizados quando houver mudança relevante no engine

Os agentes não devem:

- inventar dados ausentes sem marcar hipótese
- misturar custo direto com custo indireto sem explicitar o rateio
- publicar conclusão sem registrar critérios usados
- alterar regras, skills ou templates sem proposta explícita e revisão humana

## Como usar este diretório `.agents`
O diretório `.agents` é carregado sob demanda. O agente deve ler apenas o necessário para a tarefa atual.

Ordem geral de uso:

1. `AGENTS.md`
2. `.agents/context/*` relevante
3. `.agents/rules/*` aplicáveis
4. `.agents/skills/*` da operação atual
5. `.agents/templates/*` para entrada, saída e handoff
6. `.agents/decisions/*` quando a tarefa depender de critério formal já decidido

## Ordem de leitura recomendada das regras
Para quase toda tarefa, seguir esta sequência:

1. `.agents/rules/00-global.md`
2. `.agents/rules/10-architecture.md`
3. `.agents/rules/30-validation.md`
4. `.agents/rules/40-documentation.md`
5. `.agents/rules/50-security.md`
6. `.agents/rules/60-delivery.md`

Ler `.agents/rules/20-coding.md` apenas quando a tarefa envolver implementação ou mudança estrutural no engine.

## Convenção de fases
Toda tarefa deve declarar a fase atual. Usar uma destas fases:

- `phase-0-discovery`: entendimento do escopo, fontes e lacunas
- `phase-1-data-collection`: coleta e organização dos dados de entrada
- `phase-2-validation`: verificação de consistência, completude e qualidade
- `phase-3-costing`: cálculo de custo direto, indireto e total
- `phase-4-review`: revisão metodológica e documental
- `phase-5-publication`: publicação do relatório e atualização de registros

Se uma tarefa atravessar mais de uma fase, o agente deve explicitar:
- fase atual
- fase anterior concluída
- próxima fase sugerida

## Política de contexto mínimo
Antes de executar qualquer cálculo, o agente deve obter ou registrar explicitamente o mínimo necessário:

- produto(s) no escopo
- período de análise
- volume por produto
- custos diretos conhecidos
- custos indiretos candidatos a rateio
- critério de rateio adotado
- fonte dos dados
- nível de confiança dos dados
- hipóteses assumidas

Se algum item faltar, o agente deve:
1. registrar a lacuna
2. propor hipótese conservadora ou bloquear o cálculo, conforme criticidade
3. marcar o impacto da lacuna no resultado

## Regra de handoff
Ao encerrar uma tarefa ou sessão, sempre gerar um handoff curto usando o template apropriado.

O handoff deve conter no mínimo:

- fase atual
- objetivo da tarefa
- arquivos consultados ou alterados
- dados recebidos
- decisões tomadas
- hipóteses em aberto
- riscos
- próximo passo recomendado

Handoffs devem ser compactos, operacionais e suficientes para retomada sem releitura completa do histórico.

## Regra de validação antes de concluir uma tarefa
Nenhuma tarefa pode ser considerada concluída sem verificar:

- separação clara entre custo direto e indireto
- método de rateio explicitado
- premissas registradas
- lacunas registradas
- fórmulas ou lógica de cálculo descritas
- consistência entre números de entrada e saída
- aderência ao template de relatório
- recomendação clara de revisão humana quando houver incerteza relevante

## Quando consultar contexto, regras, templates e decisões
Consultar:

- `.agents/context/product-scope.md` para confirmar escopo funcional dos produtos fiscais
- `.agents/context/costing-method.md` para aplicar o método oficial de custeio
- `.agents/decisions/*` quando houver dúvida sobre rateio, arredondamento, publicação ou classificação de custos
- `.agents/templates/cost-input-template.md` ao receber dados
- `.agents/templates/cost-report-template.md` ao publicar resultado
- `.agents/templates/handoff.md` ao finalizar a sessão
- `.agents/templates/review-checklist.md` antes de marcar entrega como pronta

## Quando usar skills
Usar skills para fluxos repetitivos e delimitados.

Mapa inicial:

- `collect-cost-data.md`: receber e estruturar dados de entrada
- `calculate-unit-cost.md`: calcular custo unitário por produto
- `reconcile-direct-vs-indirect.md`: revisar classificação e rateio de custos
- `publish-cost-report.md`: consolidar e publicar relatório
- `evolve-engine-with-review.md`: propor evolução do engine com revisão humana

Não criar nova skill sem necessidade recorrente real.

## Quando usar subagentes
Subagentes devem ser usados apenas quando houver ganho claro de isolamento de contexto.

Mapa inicial:

- `fiscal-cost-analyst.md`: análise principal de custos fiscais
- `data-quality-reviewer.md`: revisão de qualidade e consistência dos dados
- `documentation-maintainer.md`: manutenção da documentação operacional

Se a tarefa for pequena, preferir executar sem subagente.

## Política de autoevolução assistida
Este engine permite autoevolução assistida de rules, skills e templates, desde que:

1. a lacuna seja recorrente ou estrutural
2. a proposta de mudança seja pequena, reversível e verificável
3. a motivação da mudança seja documentada
4. a revisão humana seja obrigatória antes da adoção final
5. README e CHANGELOG sejam atualizados quando a mudança afetar o uso do engine

Mudanças sugeridas pelos agentes devem ser registradas como proposta, nunca como verdade automática.

## Política operacional de segurança
Os agentes devem tratar dados operacionais e financeiros com cautela.

Regras mínimas:

- não expor credenciais, segredos ou dados sensíveis em documentos de trabalho
- não assumir acesso a fontes privadas não fornecidas
- distinguir dado confirmado de estimativa
- evitar publicação de número final sem contexto metodológico
- registrar limitações de confiança quando a base estiver incompleta

## Padrão de saída esperado
Toda saída relevante deve, quando aplicável, conter:

- objetivo
- escopo
- dados de entrada
- classificação de custos
- método de cálculo
- resultado por produto
- limitações
- recomendações
- próximos passos

## Regra de manutenção do engine
Manter este arquivo curto. Quando regras crescerem, mover detalhes para `.agents/rules/`, `.agents/skills/`, `.agents/templates/`, `.agents/context/` ou `.agents/decisions/`.

O `AGENTS.md` deve continuar sendo apenas o roteador principal.

## Artefatos-base esperados
Este repositório deve priorizar:

- `AGENTS.md`
- `.agents/rules/`
- `.agents/templates/`
- `.agents/skills/`
- `.agents/subagents/`
- `.agents/context/`
- `.agents/decisions/`

## Critério de pronto para uso em produção
O engine só deve ser usado em produção quando:

- houver método de custeio definido
- templates de entrada e saída estiverem estáveis
- regras de validação estiverem ativas
- revisão humana estiver incorporada no fluxo
- README e CHANGELOG refletirem o estado atual do engine
