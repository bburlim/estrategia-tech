# 30-validation.md

## Propósito
Definir regras de validação obrigatórias para qualquer análise de custo unitário.

O objetivo é evitar:

- erros matemáticos
- inconsistência de dados
- decisões baseadas em informação incompleta
- conclusões financeiramente perigosas

---

## 1. Validação de entrada (antes de qualquer cálculo)

O agente deve verificar:

### 1.1 Volume
- existe volume por produto?
- volume > 0?

Se não:
- bloquear cálculo OU
- marcar como inválido

---

### 1.2 Custos diretos
- existem custos diretos identificados?
- unidade está clara (ex: R$/documento)?

Se não:
- permitir cálculo com alerta de baixa precisão

---

### 1.3 Custos indiretos
- existe pelo menos um custo indireto OU justificativa de ausência?

Se existir:
- critério de rateio está definido?

Se não:
- bloquear cálculo indireto

---

### 1.4 Unidade de medida
- todas as métricas possuem unidade explícita?

Se não:
- bloquear ou corrigir antes de continuar

---

## 2. Validação de consistência lógica

### 2.1 Separação de custos
- custo direto ≠ custo indireto
- nenhum custo duplicado

---

### 2.2 Sinal dos valores
- custos não podem ser negativos (exceto ajustes explicitados)

---

### 2.3 Escopo
- todos os custos pertencem ao escopo definido?

Evitar incluir:
- custos corporativos irrelevantes
- custos de outros produtos

---

## 3. Validação de cálculo

### 3.1 Fórmulas explícitas
O agente deve verificar se:

- fórmula foi definida
- variáveis estão claras

---

### 3.2 Reprodutibilidade
Outro agente deve conseguir refazer o cálculo com:

- os mesmos dados
- as mesmas regras

---

### 3.3 Divisão por zero
Garantir que:

- nenhum denominador seja zero
- fallback definido quando necessário

---

## 4. Validação de rateio

Se houver custo indireto:

### 4.1 Critério definido
- volume?
- peso?
- consumo técnico?

---

### 4.2 Base de rateio consistente
- base utilizada corresponde ao escopo?
- soma das partes = total?

---

### 4.3 Resultado coerente
- custo indireto unitário não deve ser absurdamente desproporcional

---

## 5. Validação cruzada

### 5.1 Reconstrução do total

Verificar:

(custo_unitario_indireto * volume_total) ≈ custo_indireto_total

---

### 5.2 Ordem de grandeza

Perguntas obrigatórias:

- o valor faz sentido comparado ao mercado?
- está muito alto ou muito baixo?

Se sim:
- marcar como alerta

---

## 6. Validação de saída

Antes de publicar:

- todos os produtos possuem resultado?
- custo direto, indireto e total estão presentes?
- unidades estão consistentes?
- há explicação suficiente?

---

## 7. Classificação de confiança

Toda análise deve declarar:

- ALTA: dados completos e confiáveis
- MÉDIA: algumas estimativas
- BAIXA: lacunas relevantes

---

## 8. Tratamento de lacunas

Se faltar dado:

O agente deve:

1. listar a lacuna
2. classificar impacto (baixo, médio, alto)
3. decidir:

- bloquear cálculo
- seguir com hipótese
- seguir com range estimado

---

## 9. Alertas obrigatórios

O agente deve gerar alerta quando:

- custo indireto > custo direto (sem justificativa)
- variação extrema entre produtos
- volume muito baixo (distorce unitário)
- dados inconsistentes entre fontes

---

## 10. Revisão humana obrigatória

Resultados devem sempre recomendar revisão humana quando:

- confiança ≠ alta
- impacto financeiro relevante
- decisão estratégica envolvida

---

## 11. Proibição de conclusão silenciosa

O agente não pode:

- entregar número final sem explicar como chegou nele
- omitir limitações
- ocultar hipóteses

---

## 12. Checklist mínimo de validação

Antes de concluir, verificar:

- [ ] volume válido
- [ ] custos classificados corretamente
- [ ] fórmula explícita
- [ ] rateio definido (se aplicável)
- [ ] cálculo consistente
- [ ] unidades corretas
- [ ] lacunas registradas
- [ ] nível de confiança definido

---

## 13. Integração com templates

A validação deve alimentar:

- review-checklist.md
- cost-report-template.md

---

## 14. Falha de validação

Se qualquer validação crítica falhar:

O agente deve:

1. interromper conclusão
2. explicar o problema
3. sugerir correção
4. registrar no handoff

---
