# 20-coding.md

## Propósito
Definir padrões de implementação para quando o engine envolver criação ou alteração de código, scripts ou automações.

Ler este arquivo apenas quando a tarefa envolver implementação estrutural no engine.

---

## 1. Escopo de aplicação

Estas regras se aplicam quando:

- criar script de cálculo automatizado
- implementar parser de dados de entrada
- construir exportador de relatório
- modificar estrutura de diretórios por código
- integrar com APIs externas

Não se aplicam a:

- análises manuais em markdown
- preenchimento de templates
- tarefas de revisão ou publicação

---

## 2. Princípio de simplicidade

Preferir a solução mais simples que resolve o problema.

Evitar:

- abstrações prematuras
- dependências desnecessárias
- generalização antes de haver casos reais

---

## 3. Linguagem e formato

Para scripts e automações neste engine, preferir:

- Python para cálculo e transformação de dados
- Markdown para documentação e templates
- CSV ou JSON para troca de dados estruturados

Evitar adicionar dependências de frameworks pesados sem necessidade justificada.

---

## 4. Estrutura de script de cálculo

Todo script de cálculo deve:

- receber dados de entrada em formato explícito
- validar entrada antes de calcular
- separar lógica de cálculo da lógica de saída
- gerar saída rastreável (não apenas imprimir resultado)

---

## 5. Regra de validação no código

Todo cálculo implementado deve incluir:

- verificação de volume > 0
- verificação de denominador ≠ 0
- verificação de tipos de entrada
- mensagem de erro clara em caso de falha

---

## 6. Regra de rastreabilidade no código

Scripts devem:

- registrar os dados de entrada usados
- registrar as premissas aplicadas
- produzir log ou relatório da execução

Evitar scripts que calculam em silêncio sem registro.

---

## 7. Regra de reprodutibilidade

Um script executado duas vezes com os mesmos dados deve produzir o mesmo resultado.

Evitar:

- dependência de estado global
- leitura de variáveis de ambiente sem documentação
- uso de data/hora como variável de cálculo sem registro

---

## 8. Nomenclatura

Usar nomes descritivos:

- funções: `calcular_custo_unitario`, `ratear_indiretos`, `validar_entrada`
- variáveis: `custo_direto_unitario`, `volume_total`, `custo_indireto_por_produto`

Evitar abreviações ambíguas.

---

## 9. Separação de responsabilidades

Separar em funções ou módulos distintos:

- coleta / leitura de dados
- validação
- cálculo
- rateio
- geração de saída

---

## 10. Regra de não duplicação de lógica

Se uma regra de negócio (ex: fórmula de rateio) já existir em outro lugar do código, referenciar ou reutilizar.

Não reimplementar a mesma lógica em dois lugares.

---

## 11. Tratamento de erros

Todo script deve:

- capturar erros previsíveis explicitamente
- não silenciar exceções
- emitir mensagem útil ao operador humano

---

## 12. Sem dependência de memória externa

Scripts não devem depender de:

- cache de sessão anterior
- variáveis globais não documentadas
- arquivos temporários sem registro

---

## 13. Testes mínimos

Para qualquer função de cálculo implementada, criar ao menos:

- 1 caso feliz com valores conhecidos
- 1 caso de borda (volume zero, custo zero)
- 1 caso de erro esperado (entrada inválida)

---

## 14. Evolução de código

Mudanças em scripts existentes devem:

- ser propostas via `evolve-engine-with-review`
- não alterar comportamento sem registro
- atualizar CHANGELOG quando relevante

---

## 15. Integração com templates

Saída de scripts deve ser compatível com:

- `cost-input-template.md`
- `cost-report-template.md`

Formatos de saída devem facilitar o preenchimento dos templates, não substituí-los.
