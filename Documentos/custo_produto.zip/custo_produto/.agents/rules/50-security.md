# 50-security.md

## Propósito
Definir regras de segurança operacional para agentes que operam neste engine de custeio.

O foco é proteger dados financeiros, operacionais e sensíveis do negócio.

---

## 1. Classificação de dados sensíveis

Os seguintes dados são considerados sensíveis neste engine:

- valores reais de custo por produto
- volumes reais de documentos emitidos
- contratos com fornecedores e valores negociados
- margens e preços praticados
- dados de clientes ou contratos individuais
- credenciais de acesso a APIs e sistemas

---

## 2. Proibição de exposição de credenciais

Nenhum agente deve:

- incluir credenciais, tokens ou senhas em documentos de trabalho
- registrar chaves de API em templates, relatórios ou handoffs
- assumir acesso a sistemas privados sem fornecimento explícito pelo operador humano

Se uma análise depender de acesso a sistema externo:

- registrar a dependência como lacuna
- aguardar fornecimento explícito e seguro do acesso

---

## 3. Separação entre dado confirmado e estimativa

Dados financeiros devem sempre indicar origem:

- **confirmado**: fornecido diretamente pelo operador
- **estimado**: inferido pelo agente com hipótese declarada
- **derivado**: calculado a partir de outros dados confirmados

Nunca tratar estimativa como dado confirmado.

---

## 4. Proibição de publicação sem contexto metodológico

Nenhum número financeiro deve ser publicado sem:

- origem clara do dado
- método de cálculo
- nível de confiança
- limitações relevantes

Publicar custo unitário sem contexto cria risco de uso inadequado em decisões de pricing ou contratos.

---

## 5. Controle de acesso a fontes

O agente deve operar apenas com dados:

- fornecidos explicitamente na sessão
- presentes nos arquivos do repositório
- referenciados em fontes autorizadas pelo operador

Não acessar fontes externas não informadas.

---

## 6. Regra de minimização de dados

O agente deve usar apenas os dados necessários para a tarefa atual.

Não coletar, armazenar ou referenciar dados além do escopo da análise em andamento.

---

## 7. Tratamento de dados de clientes

Análises que envolvam dados de clientes individuais devem:

- anonimizar quando possível
- não incluir nomes de clientes em documentos de trabalho
- não vincular custo a cliente específico sem autorização explícita

---

## 8. Segurança na evolução do engine

Mudanças no engine (rules, skills, templates) não devem:

- introduzir coleta de dados não prevista
- ampliar acesso a fontes externas sem revisão
- reduzir rastreabilidade de decisões

---

## 9. Registro de limitações de confiança

Quando a base de dados estiver incompleta ou incerta:

- registrar explicitamente as limitações
- não inferir dado faltante sem marcar hipótese
- classificar o resultado como de baixa confiança quando apropriado

---

## 10. Revisão humana em análises com impacto

Toda análise com impacto financeiro relevante deve:

- recomendar revisão humana antes do uso
- identificar os pontos mais sensíveis à revisão
- não ser usada automaticamente em decisões de pricing sem validação

---

## 11. Handoff seguro

Handoffs entre sessões não devem:

- incluir dados financeiros completos desnecessariamente
- replicar dados sensíveis além do mínimo para continuidade
- incluir credenciais ou segredos

---

## 12. Regra de não persistência de dados sensíveis

Dados financeiros reais (contratos, margens, preços de fornecedores) não devem ser persistidos em arquivos do repositório sem decisão explícita do operador humano.

Se precisar persistir, o operador deve revisar e aprovar o conteúdo antes do commit.
