# 40-documentation.md

## Propósito
Definir como resultados, análises e decisões devem ser documentados neste engine.

O objetivo é garantir:

- rastreabilidade histórica
- reutilização de análises
- clareza para revisão humana
- base confiável para decisões estratégicas

---

## 1. Princípio de documentação

Toda análise relevante deve ser tratada como ativo do projeto.

Isso significa:

- não é descartável
- deve ser compreensível fora do contexto da conversa
- deve poder ser auditada posteriormente

---

## 2. Tipos de documentos suportados

O engine trabalha com os seguintes tipos:

### 2.1 Input estruturado
- dados de entrada para cálculo
- segue `cost-input-template.md`

---

### 2.2 Relatório de custo
- resultado do cálculo
- segue `cost-report-template.md`

---

### 2.3 Handoff
- continuidade entre sessões
- segue `handoff.md`

---

### 2.4 Checklist de revisão
- validação antes de publicação
- segue `review-checklist.md`

---

### 2.5 Decisões
- registradas em `.agents/decisions/`

---

## 3. Regra de uso de templates

Sempre que houver template:

- o agente deve usá-lo
- não deve criar estrutura ad-hoc
- não deve responder em formato livre

Templates garantem:

- padronização
- comparabilidade
- automação futura

---

## 4. Estrutura obrigatória de relatório

Todo relatório de custo deve conter:

- objetivo
- escopo
- período analisado
- dados de entrada
- classificação de custos
- método de cálculo
- resultado por produto
- limitações
- nível de confiança
- recomendações

---

## 5. Versionamento lógico

Cada análise deve ser tratada como uma versão lógica.

Deve incluir:

- data
- contexto
- premissas utilizadas

Evitar sobrescrever análises anteriores sem registro.

---

## 6. Registro de premissas

Toda premissa deve ser:

- explicitada
- justificada (quando possível)
- fácil de identificar

Premissas não devem ficar implícitas.

---

## 7. Registro de limitações

Toda análise deve declarar:

- o que não foi considerado
- onde há incerteza
- impacto potencial

---

## 8. Regra de clareza

O documento deve permitir que alguém:

- entenda o que foi feito
- entenda como foi feito
- refaça o cálculo

Sem depender de contexto externo.

---

## 9. Separação entre dado e interpretação

O agente deve separar:

- dados (fatos)
- interpretação (análise)
- recomendação (ação sugerida)

---

## 10. Regra de atualização

Sempre que houver:

- mudança no método de cálculo
- inclusão de novo custo
- alteração de premissa relevante

O agente deve:

1. gerar nova versão do relatório
2. registrar diferença relevante
3. atualizar CHANGELOG se aplicável

---

## 11. Integração com decisões

Quando uma análise levar a uma decisão estrutural:

- registrar em `.agents/decisions/`
- não deixar apenas no relatório

---

## 12. Proibição de documentação implícita

Não é permitido:

- deixar decisões apenas na conversa
- deixar cálculo sem registro estruturado
- depender de memória do agente

---

## 13. Regra de naming

Sugestão de nomes:

- `cost-report-YYYY-MM.md`
- `cost-input-YYYY-MM.md`

Evitar nomes genéricos como:

- resultado.md
- análise.md

---

## 14. Nível de detalhe

O documento deve ser:

- detalhado o suficiente para auditoria
- conciso o suficiente para leitura executiva

Evitar:

- excesso de narrativa
- falta de informação crítica

---

## 15. Regra de publicação

Antes de considerar um documento “publicado”:

- passou pelo checklist de revisão
- tem nível de confiança definido
- tem limitações explícitas
- está no template correto

---

## 16. Integração com README e CHANGELOG

Se a análise impactar:

- pricing
- estratégia
- método de custeio

O agente deve recomendar atualização de:

- README
- CHANGELOG

---

## 17. Documentação como base de decisão

O agente deve estruturar a saída pensando que:

- será usada por liderança
- pode embasar decisão financeira
- pode ser questionada posteriormente

---

## 18. Regra de simplicidade

Preferir:

- tabelas claras
- seções bem definidas
- linguagem objetiva

---

## 19. Evitar duplicação

Não repetir:

- regras já definidas em `rules/`
- métodos já definidos em `context/`

Referenciar ao invés de duplicar.

---

## 20. Persistência do conhecimento

Conhecimento recorrente deve migrar para:

- `context/` (se for estável)
- `decisions/` (se for escolha formal)
- `rules/` (se for comportamento obrigatório)

Nunca ficar apenas em relatórios isolados.

---
