# 10-architecture.md

## Propósito
Definir a arquitetura do modelo de custeio utilizado pelo engine.

Este documento estabelece:

- como os custos são organizados
- como são classificados
- como são transformados em custo unitário
- como garantir consistência entre análises

---

## 1. Modelo geral de custeio

O engine utiliza um modelo baseado em:

1. custo direto por unidade
2. custo indireto rateado por unidade
3. custo total unitário

Fórmula base:

custo_unitario_total = custo_direto_unitario + custo_indireto_unitario

---

## 2. Unidade de análise

A unidade padrão é:

- 1 documento fiscal emitido ou processado

Exemplos:

- 1 CT-e
- 1 NF-e
- 1 MDF-e
- 1 NFS-e
- 1 GNRE

Toda análise deve ser normalizada para essa unidade.

---

## 3. Estrutura de dados de entrada

Os dados devem ser organizados em três blocos:

### 3.1 Volume

- volume por produto (documentos/mês)

Exemplo:

- CT-e: 100000
- NF-e: 50000

---

### 3.2 Custos diretos

Custos que podem ser associados diretamente a cada documento.

Exemplos:

- custo por emissão em provider
- custo por consulta
- custo por transação bancária (GNRE)
- custo por API utilizada por documento

Formato esperado:

- custo_unitario_direto_por_produto

---

### 3.3 Custos indiretos

Custos compartilhados que precisam de rateio.

Exemplos:

- infraestrutura (cloud)
- equipe de desenvolvimento
- suporte
- monitoramento
- observabilidade

Formato esperado:

- custo_total_mensal
- critério de rateio

---

## 4. Classificação de custos

Todo custo deve ser classificado em dois eixos:

### 4.1 Direto vs indireto

- direto: atribuível por documento
- indireto: precisa de rateio

---

### 4.2 Fixo vs variável

- fixo: não varia com volume
- variável: cresce com uso

---

## 5. Estratégias de rateio (indireto)

Custos indiretos devem usar um dos seguintes critérios:

### 5.1 Por volume de documentos (default)

custo_rateado = custo_total_indireto / total_documentos

Aplicar quando:

- custo acompanha processamento geral

---

### 5.2 Por peso relativo de produto

Usar quando produtos têm complexidade diferente.

Exemplo:

- CT-e pesa 1.2
- NF-e pesa 1.0
- GNRE pesa 0.8

---

### 5.3 Por consumo técnico

Baseado em:

- CPU
- memória
- chamadas externas

Usar apenas quando dados estiverem disponíveis.

---

## 6. Pipeline de cálculo

O fluxo deve seguir esta ordem:

1. coletar dados
2. validar dados
3. calcular custo direto unitário
4. calcular base total de rateio
5. aplicar rateio de indiretos
6. calcular custo indireto unitário
7. somar custo total
8. validar consistência
9. gerar relatório

---

## 7. Estrutura de cálculo esperada

Para cada produto:

- volume
- custo_direto_unitario
- custo_indireto_unitario
- custo_total_unitario

---

## 8. Regras de consistência

O modelo deve garantir:

- soma dos custos indiretos unitários * volume = custo indireto total
- custo total nunca menor que custo direto
- ausência de divisão por zero

---

## 9. Tratamento de múltiplos produtos

Quando houver múltiplos produtos:

1. calcular custo direto individualmente
2. consolidar volume total
3. aplicar rateio compartilhado
4. recalcular custo indireto por produto

---

## 10. Tratamento de GNRE (caso especial)

GNRE pode ter duas naturezas:

- emissão
- pagamento

O modelo deve permitir:

- tratar separadamente OU
- consolidar como unidade única

A escolha deve ser registrada como decisão.

---

## 11. Tratamento de NFS-e (complexidade variável)

NFS-e pode variar por município.

O modelo deve:

- permitir média ponderada OU
- segmentação por cidade

Se usar média, registrar limitação.

---

## 12. Precisão e arredondamento

Regras:

- cálculos intermediários: alta precisão
- saída final: até 4 casas decimais
- apresentação: até 2 casas decimais

---

## 13. Evolução do modelo

O modelo pode evoluir para incluir:

- custo marginal
- custo incremental por cliente
- análise de margem

Mas a base deve permanecer:

- simples
- auditável
- reproduzível

---

## 14. Proibição de complexidade desnecessária

Evitar:

- múltiplos critérios simultâneos de rateio sem justificativa
- modelos estatísticos sem dados suficientes
- otimizações prematuras

---

## 15. Integração com templates

O modelo deve sempre alimentar:

- cost-input-template.md
- cost-report-template.md

Nenhum cálculo deve existir fora desse fluxo.

---
