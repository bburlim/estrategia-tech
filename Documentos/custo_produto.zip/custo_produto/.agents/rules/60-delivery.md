# 60-delivery.md

## Propósito
Definir os critérios de entrega de uma análise concluída neste engine.

Uma tarefa só está entregue quando cumprir todos os critérios aqui descritos.

---

## 1. Critério de conclusão de tarefa

Uma tarefa é considerada concluída quando:

- [ ] os dados de entrada estão estruturados no template
- [ ] o cálculo foi executado com fórmula explícita
- [ ] a classificação de custos foi reconciliada
- [ ] as validações foram realizadas
- [ ] o relatório foi gerado no template correto
- [ ] premissas e limitações estão registradas
- [ ] nível de confiança está declarado
- [ ] revisão humana foi recomendada quando necessário
- [ ] handoff foi gerado (se a tarefa não estiver completamente encerrada)

---

## 2. Critério de entrega de relatório

Um relatório está pronto para entrega quando:

- seguiu `cost-report-template.md`
- passou pelo `review-checklist.md`
- tem nível de confiança definido
- tem recomendação de uso explícita

---

## 3. Níveis de entrega

### Entrega completa
Relatório validado, confiança alta, recomendado para uso em decisão.

### Entrega com ressalvas
Relatório validado, confiança média, uso com cautela. Limitações explicitadas.

### Entrega parcial
Cálculo disponível mas com lacunas relevantes. Não usar para decisão financeira sem revisão adicional.

### Não entregável
Dados insuficientes para cálculo confiável. Registrar bloqueio e próximos passos.

---

## 4. Regra de handoff na entrega parcial

Quando a entrega for parcial ou o trabalho não estiver concluído:

- gerar handoff usando `handoff.md`
- registrar claramente o que falta
- indicar próxima ação recomendada

---

## 5. Rastreabilidade da entrega

Toda entrega deve permitir que outro agente ou humano:

- identifique o que foi analisado
- reproduza o cálculo com os mesmos dados
- entenda as premissas e limitações sem contexto adicional

---

## 6. Regra de naming de entrega

Relatórios entregues devem seguir o padrão:

```
cost-report-YYYY-MM.md
```

Inputs estruturados devem seguir:

```
cost-input-YYYY-MM.md
```

Análises parciais ou versões intermediárias podem usar sufixo:

```
cost-report-YYYY-MM-draft.md
```

---

## 7. Atualização de documentação na entrega

Se a entrega impactar método, escopo ou critérios do engine:

- recomendar atualização de `README.md`
- registrar entrada no `CHANGELOG.md`
- propor atualização de `context/` se o escopo mudou

---

## 8. Entrega não é publicação automática

Entregar a análise ao operador humano não significa que o resultado foi adotado como oficial.

A adoção oficial depende de:

- revisão humana
- validação pelo responsável pela área financeira ou de produto
- decisão registrada em `.agents/decisions/` quando aplicável

---

## 9. Critério de encerramento de fase

Ao encerrar uma fase:

- registrar fase concluída
- indicar próxima fase
- gerar handoff se houver continuidade

---

## 10. Proibição de entrega silenciosa

O agente não pode considerar uma tarefa entregue sem:

- comunicar o resultado explicitamente
- listar o que foi feito
- indicar o que ainda está em aberto

---

## 11. Revisão humana como gate de publicação

Para análises com impacto em decisão financeira (pricing, contrato, orçamento):

- a entrega do agente é insumo, não decisão final
- o gate de publicação final é sempre humano
- o agente deve recomendar revisão e nunca pressupor adoção automática
