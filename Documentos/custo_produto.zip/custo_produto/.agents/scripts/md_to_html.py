#!/usr/bin/env python3
"""
Converte um arquivo Markdown de relatório de custo para HTML estilizado.

Uso:
    python3 .agents/scripts/md_to_html.py cost-report-2026-01.md
    python3 .agents/scripts/md_to_html.py cost-report-2026-01.md --output relatorio.html

Dependência:
    pip install markdown
"""

import sys
import argparse
from pathlib import Path

try:
    import markdown
except ImportError:
    print("Erro: pacote 'markdown' não instalado. Execute: pip install markdown")
    sys.exit(1)

CSS = """
*, *::before, *::after { box-sizing: border-box; }

body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-size: 14px;
  line-height: 1.6;
  color: #1a1a2e;
  background: #f5f7fa;
  margin: 0;
  padding: 24px 16px;
}

.container {
  max-width: 1100px;
  margin: 0 auto;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 16px rgba(0,0,0,0.08);
  padding: 40px 48px;
}

h1 {
  font-size: 1.8rem;
  color: #0f3460;
  border-bottom: 3px solid #0f3460;
  padding-bottom: 12px;
  margin-top: 0;
}

h2 {
  font-size: 1.2rem;
  color: #16213e;
  border-bottom: 1px solid #dde3ed;
  padding-bottom: 6px;
  margin-top: 36px;
}

h3 {
  font-size: 1rem;
  color: #0f3460;
  margin-top: 24px;
}

p { margin: 8px 0 12px; }

a { color: #0f3460; }

table {
  border-collapse: collapse;
  width: 100%;
  margin: 16px 0 24px;
  font-size: 13px;
}

thead tr {
  background: #0f3460;
  color: #fff;
}

thead th {
  padding: 10px 14px;
  text-align: left;
  font-weight: 600;
  white-space: nowrap;
}

tbody tr:nth-child(even) { background: #f0f4fb; }
tbody tr:hover { background: #dde8f8; }

td {
  padding: 8px 14px;
  border-bottom: 1px solid #e2e8f0;
  vertical-align: top;
}

tbody tr:last-child td { font-weight: 600; background: #e8eef8; }

code {
  background: #f0f4fb;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 12px;
  font-family: "JetBrains Mono", "Fira Code", Consolas, monospace;
}

pre {
  background: #1a1a2e;
  color: #e2e8f0;
  padding: 16px 20px;
  border-radius: 8px;
  overflow-x: auto;
  font-size: 12px;
  line-height: 1.5;
}

pre code {
  background: none;
  padding: 0;
  color: inherit;
}

blockquote {
  border-left: 4px solid #0f3460;
  margin: 16px 0;
  padding: 8px 16px;
  background: #f0f4fb;
  border-radius: 0 6px 6px 0;
  color: #444;
}

hr {
  border: none;
  border-top: 1px solid #dde3ed;
  margin: 28px 0;
}

ul, ol { padding-left: 24px; }
li { margin: 4px 0; }

@media print {
  body { background: #fff; padding: 0; }
  .container { box-shadow: none; padding: 20px; }
}
"""

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
  <style>
{css}
  </style>
</head>
<body>
  <div class="container">
{body}
  </div>
</body>
</html>"""


def md_to_html(input_path: Path, output_path: Path) -> None:
    md_content = input_path.read_text(encoding="utf-8")

    # Extract title from first H1
    title = input_path.stem
    for line in md_content.splitlines():
        if line.startswith("# "):
            title = line[2:].strip()
            break

    md = markdown.Markdown(extensions=["tables", "toc"])
    body_html = md.convert(md_content)

    html = HTML_TEMPLATE.format(title=title, css=CSS, body=body_html)
    output_path.write_text(html, encoding="utf-8")
    print(f"HTML gerado: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Converte relatório .md para .html estilizado")
    parser.add_argument("input", help="Arquivo Markdown de entrada")
    parser.add_argument("--output", help="Arquivo HTML de saída (padrão: mesmo nome com .html)")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Erro: arquivo não encontrado: {input_path}")
        sys.exit(1)

    output_path = Path(args.output) if args.output else input_path.with_suffix(".html")
    md_to_html(input_path, output_path)


if __name__ == "__main__":
    main()
