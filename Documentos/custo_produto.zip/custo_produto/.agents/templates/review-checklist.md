# review-checklist.md

## Propósito
Garantir que uma análise de custo esteja correta, consistente e pronta para uso antes de ser publicada.

Este checklist deve ser executado antes de:

- publicar relatório
- tomar decisão baseada no resultado
- compartilhar com stakeholders

---

## 1. Validação de entrada

- [ ] volume informado para todos os produtos relevantes
- [ ] unidades consistentes (R$, documento/mês)
- [ ] fontes dos dados registradas
- [ ] período de análise definido

---

## 2. Classificação de custos

- [ ] custos diretos identificados corretamente
- [ ] custos indiretos identificados corretamente
- [ ] custos não duplicados
- [ ] custos híbridos tratados corretamente

---

## 3. Rateio de indiretos

- [ ] critério de rateio definido
- [ ] justificativa do critério registrada
- [ ] base de rateio consistente com o escopo

---

## 4. Cálculo

- [ ] fórmula explícita
- [ ] sem divisão por zero
- [ ] sem valores negativos indevidos
- [ ] custo total ≥ custo direto
- [ ] validação cruzada realizada

---

## 5. Resultado

- [ ] todos os produtos possuem custo calculado
- [ ] valores fazem sentido (ordem de grandeza)
- [ ] não há discrepâncias inexplicadas

---

## 6. Premissas e limitações

- [ ] premissas explicitadas
- [ ] limitações explicitadas
- [ ] lacunas registradas

---

## 7. Nível de confiança

- [ ] classificado (alta, média, baixa)
- [ ] justificativa clara

---

## 8. Riscos

- [ ] riscos identificados
- [ ] impacto dos riscos descrito

---

## 9. Qualidade do relatório

- [ ] segue cost-report-template.md
- [ ] leitura clara
- [ ] linguagem objetiva
- [ ] sem excesso de narrativa

---

## 10. Pronto para uso?

- [ ] pode ser usado para decisão
- [ ] usar com cautela
- [ ] não usar ainda

Justificativa:

---

## Instruções de uso

- não pular etapas
- marcar todos os itens antes de concluir
- se qualquer item crítico falhar, não publicar

---
