# cost-report-template.md

## Propósito
Padronizar a apresentação dos resultados de custo unitário dos produtos fiscais.

Este documento deve ser:

- auditável
- comparável ao longo do tempo
- compreensível por áreas técnicas e executivas

---

## 1. Identificação do relatório

- nome_da_analise:
- data:
- responsável:
- versão:
- período analisado:

---

## 2. Resumo executivo

### Objetivo
Descrever claramente o propósito da análise.

---

### Escopo
Produtos analisados:

- CT-e
- GNRE
- NFS-e
- NF-e
- MDF-e

---

### Conclusão principal

Resumo direto (exemplo):

- CT-e apresenta custo unitário de R$ X, com predominância de custo indireto
- GNRE apresenta custo elevado devido a custo bancário
- NF-e apresenta melhor eficiência de escala

---

## 3. Método de custeio

### Classificação de custos

- custo direto: custos atribuíveis por documento
- custo indireto: custos rateados

---

### Critério de rateio

Selecionado:

- [ ] por volume total
- [ ] por peso relativo
- [ ] por consumo técnico
- [ ] outro

Descrição:

---

### Regras aplicadas

- unidade de análise: documento
- período base: mensal
- arredondamento: conforme padrão do engine

---

## 4. Dados de entrada consolidados

### Volume total

| Produto | Volume (documentos/mês) |
|--------|--------------------------|
| CT-e   |                          |
| GNRE   |                          |
| NFS-e  |                          |
| NF-e   |                          |
| MDF-e  |                          |

---

### Custos diretos

Resumo por produto:

| Produto | Custo direto (R$/doc) |
|--------|------------------------|
| CT-e   |                        |
| GNRE   |                        |
| NFS-e  |                        |
| NF-e   |                        |
| MDF-e  |                        |

---

### Custos indiretos

| Tipo | Valor mensal (R$) |
|------|------------------|
| Cloud |                 |
| Engenharia |           |
| Suporte |              |
| Outros |               |

Total indireto:

---

## 5. Resultado por produto

| Produto | Volume | Custo direto (R$) | Custo indireto (R$) | Custo total (R$) |
|--------|--------|-------------------|---------------------|------------------|
| CT-e   |        |                   |                     |                  |
| GNRE   |        |                   |                     |                  |
| NFS-e  |        |                   |                     |                  |
| NF-e   |        |                   |                     |                  |
| MDF-e  |        |                   |                     |                  |

---

## 6. Análise dos resultados

### Principais drivers de custo

- quais custos mais impactam
- onde está o peso (direto vs indireto)

---

### Comparação entre produtos

- qual é mais caro
- qual é mais eficiente
- diferenças relevantes

---

### Sensibilidade

- impacto de aumento de volume
- impacto de redução de custos

---

## 7. Premissas

Listar claramente:

- 
- 
- 

---

## 8. Limitações

Listar:

- dados ausentes
- simplificações
- restrições do modelo

---

## 9. Nível de confiança

- [ ] Alta
- [ ] Média
- [ ] Baixa

Justificativa:

---

## 10. Riscos

Exemplos:

- subestimação de custos indiretos
- erro de classificação
- volume inconsistente

---

## 11. Recomendações

### Uso do resultado

- [ ] Pode ser usado para pricing
- [ ] Usar com cautela
- [ ] Não usar sem revisão adicional

---

### Ações sugeridas

- melhorar coleta de dados
- revisar rateio
- segmentar por cliente
- revisar contratos com fornecedores

---

## 12. Próximos passos

- 
- 
- 

---

## 13. Observações finais

Qualquer contexto adicional relevante.

---

## Instruções de uso

- não remover seções obrigatórias
- não ocultar premissas ou limitações
- manter consistência entre versões
- sempre revisar antes de publicar

---
