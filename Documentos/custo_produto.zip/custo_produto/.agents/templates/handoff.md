# handoff.md

## Propósito
Permitir continuidade entre sessões de forma clara, objetiva e sem perda de contexto.

Este documento deve ser gerado sempre que:

- a tarefa não estiver concluída
- houver mudança de fase
- houver necessidade de continuidade posterior
- outro agente ou pessoa assumirá a execução

---

## 1. Identificação

- data:
- responsável:
- fase atual:
- tarefa:

---

## 2. Objetivo da tarefa

Descrever de forma direta:

- o que está sendo feito
- qual o resultado esperado

---

## 3. Status atual

- [ ] não iniciado
- [ ] em andamento
- [ ] parcialmente concluído
- [ ] bloqueado

Descrição:

---

## 4. Dados utilizados

Resumo dos dados já coletados:

- volumes:
- custos diretos:
- custos indiretos:
- fontes:

---

## 5. Decisões tomadas

Listar decisões relevantes:

- 
- 
- 

---

## 6. Premissas

Listar hipóteses adotadas:

- 
- 
- 

---

## 7. Lacunas e pendências

Listar o que ainda falta:

- 
- 
- 

Classificar criticidade:

- [ ] baixa
- [ ] média
- [ ] alta

---

## 8. Riscos

Exemplos:

- dados inconsistentes
- classificação de custo incerta
- impacto alto no resultado

---

## 9. Próxima ação recomendada

Descrever claramente o próximo passo:

- 

---

## 10. Próxima fase sugerida

- phase-0-discovery
- phase-1-data-collection
- phase-2-validation
- phase-3-costing
- phase-4-review
- phase-5-publication

---

## 11. Observações adicionais

Qualquer contexto útil:

- 
- 
- 

---

## Instruções de uso

- manter curto e objetivo
- evitar repetir análise completa
- garantir que outra pessoa consiga continuar sem contexto adicional
