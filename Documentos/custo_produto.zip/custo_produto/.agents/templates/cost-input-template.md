# cost-input-template.md

## Propósito
Padronizar a entrada de dados para cálculo de custo unitário dos produtos fiscais.

Este template deve ser usado sempre que:

- iniciar uma nova análise
- revisar uma análise existente
- coletar dados de múltiplas fontes

---

## 1. Identificação da análise

- nome_da_analise:
- data:
- responsável:
- objetivo:

---

## 2. Escopo

### Produtos incluídos
- [ ] CT-e
- [ ] GNRE
- [ ] NFS-e
- [ ] NF-e
- [ ] MDF-e

### Período de análise
- início:
- fim:

---

## 3. Volume por produto

| Produto | Volume (documentos/mês) | Fonte | Observações |
|--------|--------------------------|-------|------------|
| CT-e   |                          |       |            |
| GNRE   |                          |       |            |
| NFS-e  |                          |       |            |
| NF-e   |                          |       |            |
| MDF-e  |                          |       |            |

---

## 4. Custos diretos

Registrar custos que ocorrem por documento.

| Produto | Tipo de custo | Valor (R$/documento) | Fonte | Observações |
|--------|--------------|----------------------|-------|------------|
| CT-e   |              |                      |       |            |
| NF-e   |              |                      |       |            |
| ...    |              |                      |       |            |

Exemplos:

- emissão via provider
- consulta
- API externa
- custo bancário por transação (GNRE)

---

## 5. Custos indiretos (mensais)

Registrar custos compartilhados.

| Tipo de custo | Valor mensal (R$) | Categoria | Fonte | Observações |
|--------------|------------------|----------|-------|------------|
| Cloud        |                  | Infra    |       |            |
| Engenharia   |                  | Equipe   |       |            |
| Suporte      |                  | Operação |       |            |
| Monitoramento|                  | Infra    |       |            |
| Outros       |                  |          |       |            |

---

## 6. Custos híbridos (se houver)

Custos com componente fixo + variável.

| Tipo | Parte fixa (R$/mês) | Parte variável (R$/doc) | Observações |
|------|---------------------|--------------------------|------------|
|      |                     |                          |            |

---

## 7. Critério de rateio (indiretos)

Selecionar um:

- [ ] Por volume total de documentos
- [ ] Por peso relativo por produto
- [ ] Por consumo técnico
- [ ] Outro:

Descrição:

---

## 8. Premissas

Listar hipóteses adotadas:

- 
- 
- 

---

## 9. Lacunas conhecidas

Listar dados ausentes ou incertos:

- 
- 
- 

Classificar criticidade:

- [ ] Baixa
- [ ] Média
- [ ] Alta

---

## 10. Observações adicionais

Qualquer contexto relevante:

- 
- 
- 

---

## 11. Nível de confiança inicial

- [ ] Alta
- [ ] Média
- [ ] Baixa

Justificativa:

---

## Instruções de uso

- Preencher o máximo possível antes do cálculo
- Não deixar campos críticos vazios sem registrar como lacuna
- Sempre informar fonte quando possível
- Evitar estimativas sem marcar como hipótese

---
