# evolve-engine-with-review.md

## Nome
evolve-engine-with-review

## Propósito
Permitir que o engine evolua de forma controlada, propondo melhorias em rules, skills, templates ou estrutura, sempre com revisão humana obrigatória.

Essa skill existe para:

- corrigir lacunas recorrentes
- melhorar clareza operacional
- reduzir erro humano
- adaptar o engine ao uso real

---

## Quando usar

Usar esta skill quando:

- um problema se repete em múltiplas execuções
- uma regra está ambígua ou incompleta
- uma skill está sendo usada de forma improvisada
- um template não cobre o caso real
- há necessidade clara de melhoria estrutural

Não usar quando:

- for apenas ajuste pontual de execução
- a mudança não impacta o funcionamento do engine
- a melhoria não é recorrente

---

## Entradas esperadas

A skill recebe:

- descrição do problema observado
- contexto da execução onde ocorreu
- impacto do problema
- frequência (se conhecido)
- tentativa de solução (se houve)

---

## Saída obrigatória

A saída deve conter:

- descrição do problema
- análise de causa raiz
- proposta de mudança
- impacto esperado
- risco da mudança
- arquivos afetados
- tipo de mudança
- recomendação de adoção
- necessidade de revisão humana

---

## Etapas de execução

### 1. Descrever o problema

Definir claramente:

- o que aconteceu
- em qual fase ocorreu
- qual foi o impacto

Evitar descrição vaga.

---

### 2. Classificar tipo de problema

Classificar como:

- lacuna de regra
- falha de skill
- limitação de template
- ambiguidade metodológica
- erro de uso recorrente

---

### 3. Analisar causa raiz

Identificar:

- por que o problema ocorreu
- se poderia ser evitado pelo engine atual
- se é problema estrutural ou pontual

---

### 4. Definir proposta de mudança

A proposta deve ser:

- específica
- pequena
- reversível
- clara

Exemplos:

- adicionar regra
- ajustar definição
- criar nova seção em template
- refinar etapa de skill

---

### 5. Identificar arquivos afetados

Listar:

- rules
- skills
- templates
- context
- decisions

---

### 6. Avaliar impacto

Definir:

- impacto positivo esperado
- impacto negativo possível
- risco de regressão

---

### 7. Classificar risco da mudança

- baixo
- médio
- alto

---

### 8. Definir tipo de mudança

- melhoria incremental
- correção de erro
- ajuste de clareza
- evolução estrutural

---

### 9. Recomendar adoção

Escolher:

- aplicar imediatamente com revisão
- testar em próxima execução
- manter como proposta (não aplicar ainda)

---

### 10. Exigir revisão humana

Toda proposta deve:

- ser revisada por humano
- não ser aplicada automaticamente

---

## Regras obrigatórias

- não alterar engine sem proposta formal
- não aplicar mudança silenciosamente
- não criar complexidade desnecessária
- não alterar comportamento crítico sem justificativa forte

---

## Estrutura da saída

### 1. Problema observado
- descrição clara

---

### 2. Contexto
- onde ocorreu
- fase
- impacto

---

### 3. Causa raiz
- análise objetiva

---

### 4. Proposta de mudança
- o que mudar
- como mudar

---

### 5. Arquivos afetados
- lista

---

### 6. Impacto esperado
- positivo
- negativo

---

### 7. Risco
- classificação + justificativa

---

### 8. Tipo de mudança
- categoria

---

### 9. Recomendação
- ação sugerida

---

### 10. Revisão humana
- obrigatória antes de aplicar

---

## Exemplos de uso

### Caso 1: falta de campo no template

Problema:
- usuários não informam volume por produto

Proposta:
- tornar campo obrigatório no template

---

### Caso 2: erro recorrente de classificação

Problema:
- cloud sendo classificada como custo direto

Proposta:
- reforçar regra em 00-global.md
- adicionar exemplo em skill de coleta

---

## Integração com o engine

Saída desta skill deve:

- gerar proposta documentada
- alimentar revisão humana
- opcionalmente gerar arquivo em `.agents/decisions/`

---

## Falha da skill

Se não houver evidência suficiente:

O agente deve:

1. não propor mudança
2. registrar observação
3. aguardar mais ocorrências

---
