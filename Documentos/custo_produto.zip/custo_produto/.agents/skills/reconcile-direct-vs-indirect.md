# reconcile-direct-vs-indirect.md

## Nome
reconcile-direct-vs-indirect

## Propósito
Revisar a classificação dos custos identificados e reconciliar o que é custo direto, indireto, fixo e variável antes da publicação do resultado.

Essa skill reduz risco de:

- dupla contagem
- classificação incorreta
- rateio indevido
- custo unitário artificialmente baixo ou alto

---

## Quando usar

Usar esta skill quando:

- os custos já foram coletados
- o cálculo inicial já foi feito
- houver dúvida sobre classificação
- houver custo compartilhado entre produtos
- houver risco de duplicidade

Não usar quando:

- a tarefa for apenas coleta inicial sem nenhum cálculo
- todos os custos já estiverem formalmente classificados e revisados

---

## Entradas esperadas

A skill recebe:

- lista de custos identificados
- classificação atual de cada custo
- resultado preliminar do cálculo
- critério de rateio adotado
- premissas e lacunas

---

## Saída obrigatória

A saída deve conter:

- lista reconciliada de custos
- classificação final por custo
- justificativas para ajustes
- riscos remanescentes
- recomendação de manter ou refazer cálculo

---

## Etapas de execução

### 1. Inventariar custos

Listar todos os custos usados no cálculo atual.

Para cada item, registrar:

- nome do custo
- valor
- periodicidade
- classificação atual
- produto associado (se houver)
- origem do dado

---

### 2. Revisar classificação direto vs indireto

Perguntar para cada custo:

- ele pode ser atribuído diretamente a um documento?
- ele depende de rateio?
- ele é compartilhado entre produtos?

Classificar:

- direto
- indireto

---

### 3. Revisar classificação fixo vs variável

Para cada custo:

- varia com volume?
- permanece mesmo com volume zero?
- cresce por faixas?

Classificar:

- fixo
- variável

---

### 4. Detectar dupla contagem

Verificar se um mesmo custo aparece:

- como direto e indireto
- em mais de um produto sem critério claro
- em subtotal e total simultaneamente

Se detectar, marcar como erro crítico.

---

### 5. Revisar custos limítrofes

Analisar com atenção custos que frequentemente geram erro:

- cloud compartilhada
- observabilidade
- suporte
- licenças técnicas
- provider com plano fixo + cobrança variável
- custo bancário de GNRE
- gateways municipais de NFS-e

Para cada caso, justificar a classificação adotada.

---

### 6. Revisar aderência do rateio

Se um custo foi marcado como indireto, verificar:

- o critério de rateio faz sentido?
- a base de rateio é compatível?
- o custo deveria ser parcialmente direto e parcialmente indireto?

---

### 7. Identificar custos híbridos

Alguns custos podem ter duas partes:

- componente fixo
- componente variável por documento

Nesses casos, separar explicitamente.

Exemplo:

- provider fiscal com mensalidade fixa + custo por emissão

Tratamento correto:

- mensalidade fixa → indireto ou fixo compartilhado
- custo por emissão → direto ou variável unitário

---

### 8. Reclassificar quando necessário

Se houver erro ou inconsistência:

- reclassificar custo
- justificar a mudança
- indicar impacto esperado no resultado

---

### 9. Decidir se o cálculo deve ser refeito

Refazer cálculo quando:

- houve reclassificação relevante
- houve remoção de duplicidade
- houve mudança no rateio
- houve separação de custo híbrido

Se não houver impacto relevante, registrar que o cálculo pode ser mantido.

---

### 10. Classificar confiança da reconciliação

Definir:

- ALTA: classificação consistente e justificada
- MÉDIA: algumas dúvidas marginais
- BAIXA: custos ainda ambíguos ou incompletos

---

## Regras obrigatórias

- não aceitar classificação por intuição sem justificativa
- não manter custo ambíguo sem marcar risco
- não ignorar custo híbrido
- não permitir dupla contagem

---

## Heurísticas recomendadas

### Direto
Usar como direto quando o custo:

- ocorre por documento
- é cobrado por transação
- pode ser rastreado por evento unitário

---

### Indireto
Usar como indireto quando o custo:

- atende múltiplos produtos
- é mensal ou compartilhado
- exige distribuição por critério

---

### Fixo
Usar como fixo quando:

- existe independentemente do volume no período

---

### Variável
Usar como variável quando:

- cresce com documentos, transações ou chamadas

---

## Formato de saída

### 1. Resumo executivo
- situação encontrada
- necessidade ou não de refazer cálculo

---

### 2. Tabela de reconciliação
Para cada custo:

- nome
- valor
- classificação anterior
- classificação final
- justificativa
- impacto

---

### 3. Duplicidades encontradas
- lista de erros ou “nenhuma encontrada”

---

### 4. Custos híbridos separados
- lista e tratamento adotado

---

### 5. Riscos remanescentes
- pontos ainda sensíveis

---

### 6. Recomendação
- manter cálculo
- recalcular parcialmente
- recalcular totalmente

---

### 7. Nível de confiança
- com justificativa

---

## Exemplo simplificado

Caso:

- provider fiscal cobra R$5.000/mês + R$0,08 por documento

Tratamento correto:

- R$5.000/mês → indireto
- R$0,08/documento → direto

Se antes tudo estava classificado como direto, o cálculo deve ser refeito.

---

## Integração com outras skills

Entrada vem de:

- collect-cost-data.md
- calculate-unit-cost.md

Saída alimenta:

- publish-cost-report.md

Se houver reclassificação relevante, a saída deve retroalimentar:

- calculate-unit-cost.md

---

## Falha da skill

Se a reconciliação não puder ser concluída com segurança:

O agente deve:

1. listar os custos ambíguos
2. explicar por que a classificação está insegura
3. recomendar revisão humana
4. bloquear publicação se o impacto for alto

---
