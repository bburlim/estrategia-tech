# collect-cost-data.md

## Nome
collect-cost-data

## Propósito
Receber dados de entrada de custo e volume (mesmo que incompletos ou desorganizados) e transformá-los em uma estrutura padronizada pronta para cálculo.

Essa skill é obrigatória antes de qualquer cálculo de custo unitário.

---

## Quando usar

Usar esta skill quando:

- o usuário fornecer dados de custo
- os dados estiverem incompletos ou desorganizados
- for iniciar uma análise de custo
- houver necessidade de estruturar input para cálculo

Não usar quando:

- os dados já estão estruturados no template oficial
- a tarefa for apenas revisão ou publicação

---

## Entradas esperadas

A skill aceita input em qualquer formato:

- texto livre
- listas
- tabelas informais
- estimativas

### Inputs estruturados esperados para análise de cloud (quando disponíveis)

| Input | Formato | Conteúdo |
|---|---|---|
| Volumes por produto | tabela/texto | docs/mês por produto |
| Custos diretos | tabela/texto | R$/doc por produto e tipo |
| Azure CSV | CSV com colunas: UsageDate, ServiceFamily, ServiceName, Cost | custo diário por serviço |
| Eventos CSV | CSV com colunas: corporacao, eventTopic, count, size | eventos por topic e corporação |

Se o Azure vier como valor total agregado (sem breakdown): usar fallback de rateio por volume.
Se os eventos cobrirem menos de um mês: registrar como premissa e extrapolar (ex: 1 semana × 4).

---

## Saída obrigatória

A saída deve seguir estrutura equivalente ao template:

- cost-input-template.md

---

## Etapas de execução

### 1. Identificar escopo

Extrair:

- produtos incluídos (CT-e, NF-e, etc)
- período (se informado)
- objetivo da análise (se implícito ou explícito)

---

### 2. Extrair volumes

Para cada produto:

- volume mensal (ou outro período)

Se não houver:

- marcar como lacuna crítica

---

### 3. Extrair custos diretos

Identificar:

- custos por documento
- APIs por uso
- taxas por transação
- custos bancários (GNRE)

Normalizar para:

- R$/documento

Se necessário:

- converter unidades

---

### 4. Extrair custos indiretos

Identificar:

- cloud (preferencialmente com breakdown por ServiceFamily)
- equipe
- suporte
- ferramentas

Para cada custo:

- valor mensal
- origem (se possível)
- se cloud: verificar se há CSV com breakdown por serviço Azure

Se houver CSV Azure:
- agregar por ServiceFamily para o mês completo
- verificar se total CSV bate com total informado (diferença pode ser taxas/impostos — escalonar proporcionalmente)

---

### 4.1 Processar CSV de eventos (quando disponível)

Se houver CSV de eventos:

1. Identificar colunas: corporacao, eventTopic, count, size
2. Agregar count e size por eventTopic (somando todas as corporações)
3. Classificar cada topic por produto usando `.agents/context/event-product-mapping.md`
4. Aplicar split proporcional por volume para topics multi-produto
5. Verificar cobertura temporal — se parcial, extrapolar e registrar como premissa
6. Calcular % de eventos e % de bytes por produto

---

### 5. Identificar critérios de rateio

Detectar qual método aplicar:

- Se houver breakdown de custo por componente (Azure ServiceFamily) **e** CSV de eventos: usar **método multi-critério** (seção 6 de `costing-method.md`)
- Se houver apenas total agregado de cloud: usar **fallback por volume**
- Se usuário especificar outro critério: aplicar e registrar como premissa

Registrar sempre o critério adotado — nunca assumir silenciosamente.

---

### 6. Classificar custos

Para cada custo:

- direto ou indireto
- fixo ou variável

Se houver ambiguidade:

- marcar como hipótese

---

### 7. Detectar lacunas

Listar explicitamente:

- dados ausentes
- dados ambíguos
- inconsistências

Classificar cada lacuna:

- baixa
- média
- alta criticidade

---

### 8. Normalizar unidades

Garantir:

- todos os custos em R$
- todos os volumes em documentos/mês (ou equivalente)

---

### 9. Consolidar estrutura

Gerar estrutura final:

- volumes por produto
- custos diretos por produto
- custos indiretos: total + breakdown por componente (se disponível)
- eventos por produto: % count e % bytes (se disponível)
- critérios de rateio: por componente ou fallback
- premissas
- lacunas

---

### 10. Classificar confiança

Definir:

- ALTA
- MÉDIA
- BAIXA

Com base em:

- completude
- consistência
- quantidade de estimativas

---

## Regras obrigatórias

- não inventar dados sem marcar hipótese
- não assumir rateio sem declarar
- não misturar direto e indireto
- não ignorar lacunas

---

## Formato de saída

A saída deve conter:

### 1. Escopo
- produtos
- período
- objetivo

---

### 2. Volumes
- por produto

---

### 3. Custos diretos
- por produto
- com unidade

---

### 4. Custos indiretos
- lista com valores mensais

---

### 5. Critério de rateio
- definido ou assumido

---

### 6. Premissas
- lista clara

---

### 7. Lacunas
- com criticidade

---

### 8. Nível de confiança
- justificativa

---

## Exemplo simplificado

Entrada:

"Temos 100k CT-e por mês, custo de API de 0,30 por documento e cloud de 20 mil/mês"

Saída:

- Volume CT-e: 100000
- Custo direto: R$0,30/documento
- Custo indireto: R$20000/mês
- Rateio: por volume
- Premissa: apenas CT-e considerado
- Lacuna: ausência de outros custos
- Confiança: MÉDIA

---

## Integração com outras skills

Saída desta skill deve alimentar:

- calculate-unit-cost.md
- reconcile-direct-vs-indirect.md

---

## Falha da skill

Se os dados forem insuficientes para estruturar:

O agente deve:

1. interromper
2. listar dados necessários
3. sugerir formato de input

---
