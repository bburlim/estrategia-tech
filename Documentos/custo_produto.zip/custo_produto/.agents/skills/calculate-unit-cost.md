# calculate-unit-cost.md

## Nome
calculate-unit-cost

## Propósito
Calcular o custo unitário direto, indireto e total para cada produto fiscal com base em dados previamente estruturados.

Essa skill é responsável por:

- aplicar o modelo de custeio
- executar o rateio de custos indiretos
- gerar custo unitário por produto
- garantir consistência matemática

---

## Quando usar

Usar esta skill quando:

- os dados já foram estruturados (via collect-cost-data)
- há volume definido
- há pelo menos um custo identificado

Não usar quando:

- dados ainda estão incompletos ou desorganizados
- não há volume por produto

---

## Entradas esperadas

Estrutura equivalente a:

- volumes por produto
- custos diretos por produto (R$/documento)
- custo indireto total com breakdown por componente (R$/mês por ServiceFamily — se disponível)
- % eventos por produto (para rateio de Compute)
- % bytes por produto (para rateio de Storage e Networking)
- % volume por produto (para rateio de Database e Platform)
- critério de rateio adotado
- premissas
- lacunas

---

## Saída obrigatória

Para cada produto:

- volume
- custo_direto_unitario
- custo_indireto_unitario
- custo_total_unitario

Além de:

- método de cálculo
- validações
- nível de confiança

---

## Etapas de execução

### 1. Validar entrada

Verificar:

- volume > 0
- unidades consistentes
- existência de custos

Se falhar:

- interromper ou marcar baixa confiança

---

### 2. Consolidar volume total

Calcular:

total_documentos = soma de todos os volumes

---

### 3. Calcular custo direto unitário

Para cada produto:

- usar valor informado
- se não houver:

  - assumir 0
  - marcar como lacuna

---

### 4. Calcular custo indireto total

Somar:

custo_indireto_total = soma de todos os custos indiretos mensais

---

### 5. Aplicar rateio de custos indiretos

#### 5.1 Método multi-componente (método oficial — quando houver breakdown por ServiceFamily e dados de eventos)

Para cada componente de custo indireto, aplicar o critério correspondente:

| Componente | Critério | Proxy |
|---|---|---|
| Compute (VMs, AKS) | % de eventos processados | count de eventos por produto |
| Storage | % de tamanho dos eventos | bytes por produto |
| Networking | % de tamanho dos eventos | bytes por produto |
| Database (PostgreSQL) | % de volume de documentos | documentos/mês por produto |
| Platform overhead | % de volume de documentos | documentos/mês por produto |

Fórmulas:

```
custo_compute_produto  = custo_compute_total  × (eventos_produto / total_eventos)
custo_storage_produto  = custo_storage_total  × (bytes_produto   / total_bytes)
custo_network_produto  = custo_network_total  × (bytes_produto   / total_bytes)
custo_database_produto = custo_database_total × (volume_produto  / total_volume)
custo_platform_produto = custo_platform_total × (volume_produto  / total_volume)

custo_indireto_produto = soma dos 5 componentes acima
custo_indireto_unitario_produto = custo_indireto_produto / volume_produto
```

Validação: soma dos custos por produto deve igualar o custo indireto total.

---

#### 5.2 Fallback: por volume total (quando não houver breakdown)

Se o custo indireto não puder ser decomposto por componente:

```
custo_indireto_unitario = custo_indireto_total / total_documentos
```

Registrar como premissa ao usar o fallback.

---

Se critério não definido:

- usar fallback por volume
- registrar como premissa

---

### 6. Calcular custo indireto por produto

Para cada produto:

- se método multi-componente: somar os 5 componentes calculados na etapa 5.1
- se fallback: aplicar o valor base uniforme da etapa 5.2

---

### 7. Calcular custo total unitário

Para cada produto:

custo_total_unitario = custo_direto_unitario + custo_indireto_unitario

---

### 8. Validar consistência

Verificar:

- custo_total ≥ custo_direto
- nenhum valor negativo
- coerência entre produtos

---

### 9. Validação cruzada

Verificar:

(custo_indireto_unitario * total_documentos) ≈ custo_indireto_total

---

### 10. Identificar outliers

Detectar:

- custo muito alto ou baixo comparado aos outros
- diferença extrema entre produtos

---

### 11. Classificar confiança

Baseado em:

- completude dos dados
- quantidade de estimativas
- qualidade do rateio

---

## Regras obrigatórias

- não recalcular dados sem registrar
- não alterar premissas silenciosamente
- não ignorar lacunas críticas
- não simplificar rateio sem justificar

---

## Formato de saída

### 1. Resumo

- total de documentos
- custo indireto total

---

### 2. Resultado por produto

Para cada produto:

- volume
- custo direto unitário
- custo indireto unitário
- custo total unitário

---

### 3. Método de cálculo

- fórmula usada
- critério de rateio

---

### 4. Validações

- checks realizados
- inconsistências encontradas

---

### 5. Premissas

---

### 6. Lacunas

---

### 7. Nível de confiança

---

## Exemplo simplificado

### Fallback (sem breakdown)

Entrada:
- CT-e: 100.000 docs, custo direto R$0,30
- custo indireto total: R$20.000, volume total: 100.000

Cálculo:
- indireto unitário: 20.000 / 100.000 = R$0,20
- total: R$0,30 + R$0,20 = R$0,50

---

### Multi-componente (com breakdown)

Entrada:
- CT-e: 100.000 docs, 70% dos eventos, 60% dos bytes
- NF-e: 900.000 docs, 30% dos eventos, 40% dos bytes
- Compute: R$10.000, Storage: R$5.000, Database: R$8.000

Cálculo CT-e:
- compute:  R$10.000 × 70% = R$7.000
- storage:  R$5.000  × 60% = R$3.000
- database: R$8.000  × 10% = R$800  (10% do volume = 100k / 1.000k)
- total indireto CT-e: R$10.800
- custo indireto unitário CT-e: R$10.800 / 100.000 = R$0,1080

---

## Integração com outras skills

Entrada vem de:

- collect-cost-data.md

Saída alimenta:

- reconcile-direct-vs-indirect.md
- publish-cost-report.md

---

## Falha da skill

Se houver erro crítico:

O agente deve:

1. interromper
2. explicar problema
3. sugerir correção
4. registrar no handoff

---
