# publish-cost-report.md

## Nome
publish-cost-report

## Propósito
Consolidar os resultados validados de custo unitário em um relatório padronizado, auditável e publicável para uso operacional, gerencial e estratégico.

Essa skill é responsável por:

- transformar cálculo em documento final
- explicitar método, premissas e limitações
- padronizar a apresentação por produto
- preparar a análise para revisão humana e decisão

---

## Quando usar

Usar esta skill quando:

- os dados já foram coletados
- o cálculo foi executado
- a validação foi concluída
- a reconciliação de custos foi feita ou considerada suficiente

Não usar quando:

- ainda houver falha crítica de validação
- houver custo ambíguo com alto impacto sem revisão
- o cálculo ainda precisar ser refeito

---

## Entradas esperadas

A skill recebe:

- resultado do cálculo por produto
- custos reconciliados
- método de rateio
- premissas
- lacunas
- limitações
- nível de confiança
- período de análise

---

## Saída obrigatória

A saída deve seguir o template:

- `cost-report-template.md`

E conter, no mínimo:

- objetivo
- escopo
- período
- método de custeio
- resultado por produto
- limitações
- riscos
- recomendações
- próximo passo sugerido

---

## Etapas de execução

### 1. Confirmar elegibilidade para publicação

Verificar:

- cálculo concluído
- validação concluída
- classificação de custos revisada
- nível de confiança definido

Se não:
- bloquear publicação

---

### 2. Consolidar contexto da análise

Registrar:

- objetivo da análise
- produtos incluídos
- período considerado
- fonte dos dados
- fase atual

---

### 3. Consolidar método aplicado

Documentar de forma clara:

- definição de custo direto
- definição de custo indireto
- critério de rateio
- regra de arredondamento
- tratamento de exceções relevantes

---

### 4. Montar tabela principal por produto

Para cada produto:

- volume
- custo direto unitário
- custo indireto unitário
- custo total unitário
- observações relevantes

Produtos no escopo inicial:

- CT-e
- GNRE
- NFS-e
- NF-e
- MDF-e

---

### 5. Destacar premissas

Listar de forma explícita:

- hipóteses adotadas
- critérios assumidos
- simplificações feitas

Não esconder premissas em texto corrido.

---

### 6. Destacar limitações

Listar:

- dados faltantes
- aproximações
- restrições metodológicas
- impacto potencial das lacunas

---

### 7. Classificar risco da análise

Classificar risco de uso do resultado:

- baixo
- médio
- alto

Com base em:

- incerteza dos dados
- sensibilidade do cálculo
- grau de estimativa

---

### 8. Definir recomendação executiva

A saída deve recomendar uma destas ações:

- usar os valores como referência operacional
- usar com cautela e revisar pontos críticos
- não usar para decisão financeira até revisão adicional

---

### 9. Recomendar próximos passos

Exemplos:

- coletar custos faltantes
- separar custo híbrido
- refazer rateio
- revisar volume por produto
- registrar decisão formal no diretório `.agents/decisions/`

---

### 10. Preparar para persistência documental

Gerar os seguintes arquivos:

- `cost-report-YYYY-MM.md` — relatório em Markdown (fonte)
- `cost-report-YYYY-MM.html` — versão HTML gerada a partir do Markdown

---

### 11. Gerar versão HTML

Após salvar o `.md`, converter para HTML usando o script padrão do engine:

```bash
python3 .agents/scripts/md_to_html.py cost-report-YYYY-MM.md
```

O script gera `cost-report-YYYY-MM.html` no mesmo diretório.

Se o script não existir: executar o comando Python equivalente inline (ver `.agents/scripts/md_to_html.py` para o padrão de estilo).

---

## Regras obrigatórias

- não publicar resultado sem limitações
- não omitir nível de confiança
- não resumir demais a ponto de perder auditabilidade
- não transformar hipótese em fato
- não declarar “custo real” quando a base for estimada

---

## Estrutura obrigatória da saída

### 1. Resumo executivo
- objetivo
- período
- escopo
- conclusão principal

---

### 2. Método utilizado
- como custos foram classificados
- como indiretos foram rateados

---

### 3. Resultado por produto
Tabela com:

- produto
- volume
- custo direto unitário
- custo indireto unitário
- custo total unitário

---

### 4. Premissas
Lista explícita

---

### 5. Limitações
Lista explícita

---

### 6. Nível de confiança
- alta
- média
- baixa
- justificativa

---

### 7. Riscos
- principais riscos de interpretação ou uso

---

### 8. Recomendação
- uso sugerido do relatório

---

### 9. Próximos passos
- ações recomendadas

---

## Heurísticas de escrita

Preferir:

- linguagem objetiva
- leitura executiva
- tabelas simples
- observações curtas e úteis

Evitar:

- narrativa longa
- repetição da lógica já registrada em rules
- excesso de detalhe matemático no resumo executivo

Detalhes de cálculo devem existir, mas em seção própria.

---

## Exemplo simplificado de saída

Produto: CT-e  
Volume: 100000  
Custo direto unitário: R$0,30  
Custo indireto unitário: R$0,20  
Custo total unitário: R$0,50

Premissa: rateio por volume total  
Limitação: ausência de segmentação por tipo de cliente  
Confiança: média

---

## Integração com outras skills

Entrada vem de:

- calculate-unit-cost.md
- reconcile-direct-vs-indirect.md

Saída deve alimentar:

- handoff.md
- review-checklist.md

Pode também gerar insumo para:

- `.agents/decisions/`
- README
- CHANGELOG

---

## Falha da skill

Se a publicação não puder ser concluída com segurança:

O agente deve:

1. explicar o motivo
2. listar pendências
3. recomendar correção
4. registrar handoff
5. não marcar o relatório como pronto

---
