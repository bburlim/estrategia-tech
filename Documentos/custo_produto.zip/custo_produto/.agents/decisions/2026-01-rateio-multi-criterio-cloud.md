# Decisão: critério de rateio multi-componente para custos de cloud

**Data:** 2026-03-30
**Análise de referência:** cost-report-2026-01.md v2.0

---

## Decisão

Adotar critério de rateio **multi-componente** para custos de cloud, onde cada família de serviço Azure usa o critério que melhor representa seu consumo real.

---

## Critérios por componente

| Componente Azure | Critério de rateio | Proxy usado |
|---|---|---|
| Compute (VMs, AKS) | Eventos processados (count) | % de eventos por produto |
| Storage | Tamanho dos eventos (bytes) | % de bytes processados por produto |
| Networking | Tamanho dos eventos (bytes) | % de bytes processados por produto |
| Database (PostgreSQL) | Volume de documentos | % de documentos por produto |
| Platform overhead | Volume de documentos | % de documentos por produto |

---

## Justificativa por componente

- **Compute:** custo de CPU e processamento acompanha diretamente o número de eventos gerados por produto. Mais eventos = mais compute consumido.
- **Storage:** custo de armazenamento e escrita acompanha o volume de bytes processados. Produtos com arquivos maiores e maior volume de eventos têm maior footprint.
- **Networking:** custo de transferência de dados acompanha o volume de bytes movimentados entre serviços.
- **Database:** sem dado de GB por produto disponível, volume de documentos é o melhor proxy disponível para o footprint no banco.
- **Platform:** custos não atribuíveis diretamente a produto (DevOps, Log Analytics, Monitor) são distribuídos por volume como overhead fixo proporcional.

---

## Fonte dos dados de eventos

- Arquivo: `grouped-jan-consolidated(Data).csv`
- Cobertura: 1 semana
- Extrapolação para o mês: ×4
- Mapeamento de 435 event topics para 5 produtos + categoria Platform

---

## Substituição da decisão anterior

Esta decisão substitui o critério PSC único (Volume × KB) registrado em `2026-01-rateio-consumo-tecnico-kb.md`.

O critério PSC continua válido como referência histórica, mas não é o método oficial a partir desta versão.

---

## Limitações da decisão

- Rateio de Database por volume é uma aproximação — deve ser revisado quando dados de GB por produto estiverem disponíveis
- Eventos são de 1 semana extrapolada — revisar quando houver eventos de mês completo
- Categoria Platform (24% dos eventos) distribuída proporcionalmente — metodologia pode ser refinada

---

## Revisão recomendada quando

- Dados de GB por produto no banco estiverem disponíveis
- Houver eventos cobrindo um mês completo
- Um novo produto for incluído no escopo
- A arquitetura de serviços Azure mudar significativamente
