# Decisão: critério de rateio por consumo técnico (KB)

**Data:** 2026-01-01 (referência) / registrado em 2026-03-30
**Fase:** phase-3-costing
**Análise de referência:** cost-report-2026-01.md

---

## Decisão

O critério de rateio de custos indiretos de cloud adotado é **por consumo técnico**, medido em KB por arquivo processado.

### Fórmula

```
PSC_produto = volume_produto × tamanho_kb_produto
% rateio_produto = PSC_produto / PSC_total
custo_indireto_produto = custo_indireto_total × % rateio_produto
custo_unitario_produto = custo_indireto_produto / volume_produto
```

---

## Tamanhos adotados (KB por arquivo)

| Produto | Tamanho (KB) |
|--------|-------------|
| CT-e   | 9           |
| GNRE   | 200         |
| NFS-e  | 5           |
| NF-e   | 5           |
| MDF-e  | — (não definido ainda) |

---

## Justificativa

O tamanho em KB representa o consumo real de infraestrutura por documento na plataforma.
Usar volume puro seria injusto pois GNRE, apesar de menor volume, gera carga significativamente maior por arquivo (200 KB vs 5–9 KB dos demais).

O critério de consumo técnico distribui o custo de cloud proporcionalmente ao uso real da infraestrutura.

---

## Fonte dos dados de tamanho

Planilha financeira — dados confirmados pela operação.

---

## Limitações

- Tamanho em KB representa média por arquivo no período; pode variar entre clientes ou tipos de operação
- MDF-e ainda sem tamanho definido — incluir quando o produto entrar no escopo de análise
- Revisar tamanhos periodicamente se a estrutura dos arquivos mudar

---

## Impacto no resultado

GNRE recebe rateio desproporcional ao seu volume por ter KB/arquivo muito superior aos outros produtos.
Isso é correto metodologicamente — reflete consumo real.

---

## Revisão

Esta decisão deve ser revisada se:
- o tamanho médio dos arquivos mudar significativamente
- um novo produto for incluído no escopo
- houver mudança na arquitetura de storage/processamento da plataforma
