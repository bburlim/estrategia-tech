# costing-method.md

## Propósito
Definir o método oficial de custeio unitário adotado por este engine.

Este documento é a fonte de verdade metodológica. Qualquer análise deve seguir o método aqui descrito.

---

## 1. Objetivo do método

Calcular o **custo unitário direto, indireto e total** de cada produto fiscal, por documento emitido ou processado, de forma:

- repetível
- auditável
- comparável entre períodos

---

## 2. Modelo adotado

O engine utiliza **custeio por absorção com rateio multi-componente**, adaptado para operações SaaS de documentos fiscais.

### Fórmula base

```
custo_total_unitario = custo_direto_unitario + custo_indireto_unitario
```

O custo indireto unitário é a soma dos rateios de cada componente de custo:

```
custo_indireto_unitario = Σ (custo_componente × % produto no componente) / volume_produto
```

Cada componente usa o critério de rateio que melhor representa seu consumo real — ver seção 6.

---

## 3. Definição de custo direto

Custo direto é todo custo **atribuível individualmente a um documento**.

Exemplos:

- custo de emissão cobrado por provider fiscal (ex: R$/documento)
- custo de API externa cobrada por chamada vinculada ao documento
- custo bancário por guia GNRE emitida e paga
- custo de gateway municipal por NFS-e emitida
- custo de consulta por documento

**Critério prático:** se o custo pode ser rastreado até um evento unitário (emissão, consulta, transação), é direto.

---

## 4. Definição de custo indireto

Custo indireto é todo custo **compartilhado entre produtos ou operações**, que precisa de critério de rateio.

Exemplos:

- infraestrutura de cloud (servidores, banco de dados, filas)
- equipe de engenharia alocada ao produto fiscal
- suporte operacional
- monitoramento e observabilidade
- licenças de ferramentas compartilhadas

**Critério prático:** se o custo não pode ser rastreado diretamente a um documento sem distribuição, é indireto.

---

## 5. Classificação complementar: fixo vs variável

Todo custo deve também ser classificado como:

- **fixo**: não varia com o volume de documentos no período (ex: mensalidade de cloud, salário)
- **variável**: cresce proporcionalmente ao volume (ex: custo por transação, por chamada de API)

Custos híbridos (parte fixa + parte variável) devem ser separados antes do cálculo.

---

## 6. Critério de rateio multi-componente (método oficial)

Quando o custo indireto puder ser decomposto por tipo de serviço (ex: Azure por ServiceFamily), aplicar critério específico por componente:

| Componente | Critério de rateio | Proxy |
|---|---|---|
| Compute (VMs, AKS, funções) | % de eventos processados | count de eventos por produto |
| Storage (blob, object) | % de tamanho de eventos (bytes) | bytes processados por produto |
| Networking (bandwidth, DNS) | % de tamanho de eventos (bytes) | bytes processados por produto |
| Database (PostgreSQL, etc.) | % de volume de documentos | documentos/mês por produto |
| Platform overhead (DevOps, Monitor) | % de volume de documentos | documentos/mês por produto |

### Fórmulas

```
% eventos_produto   = eventos_produto / total_eventos
% bytes_produto     = bytes_produto   / total_bytes
% volume_produto    = volume_produto  / total_volume

custo_compute_produto  = custo_compute_total  × % eventos_produto
custo_storage_produto  = custo_storage_total  × % bytes_produto
custo_network_produto  = custo_network_total  × % bytes_produto
custo_database_produto = custo_database_total × % volume_produto
custo_platform_produto = custo_platform_total × % volume_produto

custo_indireto_unitario = (soma de todos os componentes) / volume_produto
```

### Fallback

Se o custo indireto não puder ser decomposto por componente, usar **por volume total de documentos**:

```
custo_indireto_unitario = custo_indireto_total / total_documentos
```

Registrar como premissa quando usar o fallback.

---

## 7. Eventos multi-produto

Alguns event topics pertencem a mais de um produto (ex: webhooks genéricos, eventos de carga com múltiplos documentos).

Nesses casos, distribuir o evento proporcionalmente pelo volume dos produtos relevantes:

```
ratio_produto = volume_produto / soma_volumes_produtos_relevantes
eventos_produto += eventos_topic × ratio_produto
```

Os topics multi-produto e seus produtos relevantes devem estar documentados em:
- `.agents/context/event-product-mapping.md`

---

## 7.1 Critério de rateio legado (PSC)

O critério PSC (Volume × KB por arquivo) foi usado até 01/2026 v1.0. Está depreciado.

Referência histórica em: `.agents/decisions/2026-01-rateio-consumo-tecnico-kb.md`

---

## 8. Pipeline de cálculo obrigatório

Toda análise deve seguir esta sequência:

1. Coletar dados (`collect-cost-data`)
   - volumes por produto
   - custos diretos por produto
   - custo indireto total com breakdown por componente (ex: Azure CSV por ServiceFamily)
   - eventos por topic (CSV de eventos) — para rateio de compute/storage/networking
2. Classificar eventos por produto (`event-product-mapping.md`)
   - aplicar split multi-produto onde aplicável
   - extrapolação se dados forem parciais (ex: 1 semana × 4)
3. Validar completude e consistência (`30-validation`)
4. Calcular custo direto unitário por produto
5. Calcular rateio por componente de custo indireto (seção 6)
6. Somar custo indireto unitário por produto
7. Somar custo total unitário
8. Validar consistência cruzada
9. Reconciliar classificação (`reconcile-direct-vs-indirect`)
10. Gerar relatório (`publish-cost-report`)

---

## 9. Tratamento de lacunas de dados

Se faltar custo direto para um produto:

- registrar como lacuna
- assumir custo direto = 0 com nível de confiança BAIXO
- marcar explicitamente no relatório

Se faltar volume para um produto:

- bloquear cálculo para aquele produto
- não incluir no denominador do rateio sem confirmação

Se faltar custo indireto:

- registrar lacuna com impacto
- calcular apenas custo direto se possível
- classificar confiança como BAIXA

---

## 10. Precisão e arredondamento

| Etapa | Precisão |
|-------|---------|
| Cálculos intermediários | máxima disponível |
| Resultado por produto | 4 casas decimais |
| Apresentação executiva | 2 casas decimais |

---

## 11. Período de análise

O período padrão de análise é **mensal**.

Custos fornecidos em outras periodicidades devem ser convertidos:

- anual → dividir por 12
- diário → multiplicar por dias úteis do mês (ou 30 se não especificado)
- pontual → tratar como hipótese com justificativa

---

## 12. Limitações do método

Este método não cobre diretamente:

- custo marginal por cliente
- custo de aquisição ou onboarding
- custo de desenvolvimento de novas features
- análise de margem ou pricing

Essas análises podem ser construídas sobre os resultados deste engine, mas estão fora do escopo atual.

---

## 13. Critério de revisão do método

Este método deve ser revisado quando:

- houver mudança significativa na estrutura de custos
- um novo produto for incluído
- o critério de rateio padrão se mostrar inadequado
- houver decisão formal de adotar custeio por atividade (ABC) ou outro modelo

Revisões devem passar por proposta + revisão humana conforme `evolve-engine-with-review`.

---

## 14. Referência cruzada

- Regras de validação: `.agents/rules/30-validation.md`
- Regras arquiteturais: `.agents/rules/10-architecture.md`
- Escopo de produtos: `.agents/context/product-scope.md`
- Classificação de eventos: `.agents/context/event-product-mapping.md`
- Skills de execução: `.agents/skills/`
- Decisão do método multi-critério: `.agents/decisions/2026-01-rateio-multi-criterio-cloud.md`
