# product-scope.md

## Propósito
Definir o escopo funcional oficial dos produtos fiscais operados pelo SaaS e cobertos por este engine de custeio.

---

## Produtos no escopo

### CT-e — Conhecimento de Transporte Eletrônico

- Tipo: documento fiscal de transporte de cargas
- Emissão: por operação de transporte rodoviário, aéreo, aquaviário, ferroviário ou dutoviário
- Natureza da operação: emissão ou consulta/recebimento
- Particularidades: pode envolver múltiplos eventos (cancelamento, EPEC, carta de correção)
- Complexidade relativa: média-alta (múltiplos eventos por documento)

---

### NF-e — Nota Fiscal Eletrônica

- Tipo: documento fiscal de circulação de mercadorias (ICMS)
- Emissão: por operação de venda ou transferência de mercadorias
- Natureza da operação: emissão, consulta, manifestação do destinatário
- Particularidades: pode envolver eventos complementares (cancelamento, carta de correção, manifestação)
- Complexidade relativa: média (produto de maior volume no mercado)

---

### NFS-e — Nota Fiscal de Serviços Eletrônica

- Tipo: documento fiscal de prestação de serviços (ISS)
- Emissão: por operação de serviço prestado
- Natureza da operação: emissão e consulta
- Particularidades: regulamentação municipal — cada cidade tem regras, endpoints e formatos próprios
- Complexidade relativa: alta (variabilidade por município exige adaptação de integração)
- Atenção: custo pode variar por cidade; análise deve registrar se usa média ponderada ou segmentação

---

### GNRE — Guia Nacional de Recolhimento de Tributos Estaduais

- Tipo: guia de arrecadação de tributos interestaduais
- Uso: emissão e pagamento de GNRE vinculada a CT-e com operação interestadual
- Natureza da operação: emissão da guia e pagamento bancário
- Particularidades: envolve custo bancário por transação além do custo de emissão
- Complexidade relativa: média (custo bancário é componente relevante e distinto)
- Atenção: GNRE pode ser tratada como documento autônomo ou como evento vinculado ao CT-e; a escolha deve ser registrada como decisão

---

### MDF-e — Manifesto Eletrônico de Documentos Fiscais

- Tipo: documento fiscal que vincula CT-e a veículos e motoristas em operações de transporte
- Emissão: por viagem ou lote de documentos transportados
- Natureza da operação: emissão, encerramento, eventos
- Particularidades: geralmente emitido em conjunto com CT-e; volume tende a ser menor
- Complexidade relativa: baixa-média (menor volume relativo, mas processo vinculado ao CT-e)

---

## Produtos fora do escopo atual

Produtos não listados acima não devem ser incluídos em análises sem expansão formal do escopo.

Exemplos fora do escopo atual:

- NFC-e (Nota Fiscal do Consumidor Eletrônica)
- BP-e (Bilhete de Passagem Eletrônico)
- CF-e (Cupom Fiscal Eletrônico)
- Outros documentos fiscais estaduais ou federais

---

## Unidade de análise padrão

A unidade padrão de custo para todos os produtos é:

- 1 documento emitido ou processado

Para GNRE, considerar também:

- 1 guia emitida + paga (como unidade composta)

Para NFS-e, considerar:

- 1 nota emitida (com possível ajuste por município)

---

## Critério de inclusão de evento adicional

Eventos vinculados a um documento (cancelamento, carta de correção, manifestação) devem ser tratados como:

- incluídos no custo do documento principal (se o volume for proporcionalmente pequeno), OU
- tratados como unidade separada (se o volume for expressivo)

A escolha deve ser registrada como premissa ou decisão em cada análise.

---

## Referência de volume esperado

Volume indicativo para calibragem de análise (não usar como dado real sem confirmação):

| Produto | Relação de volume esperada |
|--------|---------------------------|
| NF-e   | mais alto                 |
| CT-e   | segundo maior             |
| NFS-e  | variável por cliente      |
| MDF-e  | proporcional ao CT-e      |
| GNRE   | proporcional ao CT-e interestadual |

Confirmar volume real com a área de dados antes de qualquer análise.

---

## Atualização deste documento

Este documento deve ser atualizado quando:

- um novo produto for incluído no escopo
- a natureza operacional de um produto mudar
- houver decisão formal de excluir um produto

Mudanças devem ser registradas no CHANGELOG.
