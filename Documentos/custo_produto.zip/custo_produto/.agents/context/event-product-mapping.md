# event-product-mapping.md

## Propósito

Persistir as regras de classificação de event topics para os produtos fiscais da plataforma.

Este documento é a fonte de verdade para mapeamento de eventos. Ao ser usado em análises futuras, evita reclassificar os 435+ topics do zero a cada ciclo.

---

## 1. Regras de classificação (por ordem de prioridade)

### Prioridade 1 — Topics multi-produto (lista explícita)

Se o topic estiver na lista da seção 2, aplicar split proporcional por volume.
Não tentar inferir pelo nome — a lista prevalece.

### Prioridade 2 — Produto explícito no nome

Se o nome contiver o identificador do produto (case-insensitive), classificar diretamente:

| Padrão no nome | Produto |
|---|---|
| `CTE_`, `_CTE_`, `_CTE` | CT-e |
| `GNRE_`, `_GNRE_`, `_GNRE` | GNRE |
| `NFSE_`, `_NFSE_`, `NFS_E`, `_NFE_MUNICIPAL` | NFS-e |
| `NFE_`, `_NFE_`, `_NFE` (sem NFSE) | NF-e |
| `MDFE_`, `_MDFE_`, `_MDFE`, `MDF_E` | MDF-e |

Confiança: **100%**

### Prioridade 3 — Keyword exclusivo de produto

Se o nome contiver keyword exclusivo de operação de produto:

| Keyword | Produto | Confiança | Justificativa |
|---|---|---|---|
| `AVERBACAO` | CT-e | 95% | Averbação de seguro de carga — exclusiva de CT-e |
| `CIOT` | CT-e | 95% | CIOT (pagamento de frete) — exclusivo de CT-e |
| `SHOPEE` | CT-e | 85% | Integração Shopee logística — nome genérico, mas fortemente ligada a CT-e |
| `LINE_HAUL` | CT-e | 80% | Transporte de linha — CT-e por natureza |
| `FITBANK`, `BRADESCO` | GNRE | 90% | Providers de pagamento GNRE |
| `BOLETO`, `COBRANCA` | GNRE | 85% | Operações financeiras de GNRE |
| `PREFEITURA`, `MUNICIPAL` | NFS-e | 90% | Serviços municipais — escopo NFS-e |
| `TOMADOR` | NFS-e | 85% | Tomador de serviço — conceito de NFS-e |
| `DANFE` | NF-e | 95% | DANFE é exclusivo de NF-e |
| `MELI` (sem `REDISPATCH`) | NF-e | 75% | Integração Mercado Livre |
| `REDISPATCH_MELI` | CT-e + MDF-e | 100% | Validado pelo usuário — ver seção 2 |
| `HU_CONSULTA`, `_HU_` | CT-e + MDF-e | 100% | Validado pelo usuário — HU = Handling Unit (tracking logístico CT-e/MDF-e) |

### Prioridade 4 — Fallback: Platform

Se o topic não se enquadrar em nenhuma regra acima, classificar como **Platform**.

Platform é distribuído proporcionalmente entre todos os produtos ao final do cálculo.

---

## 2. Topics multi-produto (lista validada)

Estes topics foram validados pelo usuário. O split é proporcional ao volume dos produtos relevantes.

| Event Topic | Produtos | Data de validação | Justificativa |
|---|---|---|---|
| `NOTIFICACAO_DOCS_CARGA_RECEBIDA` | CT-e, MDF-e | 2026-03-30 | Shopee solicita nova notificação — pode ser CT-e, MDF-e ou referências de carga |
| `STATUS_DOCUMENTO_CARGA_ATUALIZADO` | CT-e, NFS-e | 2026-03-30 | Gerado quando CT-e ou NFS-e é autorizado/rejeitado em carga |
| `TODOS_DOCUMENTOS_CARGA_PROCESSADOS` | CT-e, NFS-e | 2026-03-30 | Gerado quando todos os CT-e e NFS-e de uma carga são processados |
| `CONSULTA_ITEM_LINE_HAUL_SOLICITADO` | CT-e, MDF-e | 2026-03-30 | Consulta de tracking de linha haul — envolve CT-e e MDF-e |
| `HU_CONSULTADO` | CT-e, MDF-e | 2026-03-30 | HU = Handling Unit — tracking logístico de CT-e e MDF-e |
| `CONSULTA_HU_SOLICITADA` | CT-e, MDF-e | 2026-03-30 | Solicitação de consulta HU — idem |
| `DOCUMENT_ROUTE_REDISPATCH_MELI_CONSULTADO` | CT-e, MDF-e | 2026-03-30 | Redispatch MELI — validado como CT-e+MDF-e (não NF-e) |
| `ROUTE_REDISPATCH_MELI_CONSULTADA` | CT-e, MDF-e | 2026-03-30 | Redispatch MELI — idem |
| `CONSULTA_ROUTE_REDISPATCH_MELI_SOLICITADA` | CT-e, MDF-e | 2026-03-30 | Redispatch MELI — idem |
| `WEBHOOK_NOTIFICADO` | CT-e, GNRE, NFS-e, NF-e, MDF-e | 2026-03-30 | Notificação via webhook padrão — dispara para qualquer documento da plataforma |
| `INTEGRACAO_DOCUMENTO_INICIADA` | CT-e, GNRE, NFS-e, NF-e, MDF-e | 2026-03-30 | Gerado para todos os documentos ao iniciar integração |

### Fórmula de split

```
ratio_produto = volume_produto / soma_volumes_produtos_relevantes
eventos_produto += count_topic × ratio_produto
bytes_produto   += size_topic  × ratio_produto
```

---

## 3. Critérios de confiança

| Confiança | Critério |
|---|---|
| 100% | Produto explícito no nome do evento OU validado explicitamente pelo usuário |
| 95% | Keyword exclusivo de operação do produto (ex: CIOT, AVERBACAO) |
| 90% | Keyword fortemente associado ao produto (ex: FITBANK → GNRE) |
| 85% | Keyword associado mas nome do evento genérico (ex: SHOPEE → CT-e) |
| 80% | Inferência por contexto operacional (ex: LINE_HAUL → CT-e) |
| < 80% | Classificar como Platform ou validar antes de usar |

---

## 4. Categoria Platform

Topics não classificáveis nas regras acima vão para Platform.

Platform **não é um produto** — é um bucket de distribuição proporcional.

Ao calcular o rateio, os eventos Platform são distribuídos entre os 5 produtos proporcionalmente à participação de cada produto no total de eventos classificados.

**Alvo operacional:** Platform deve representar < 5% do total de eventos. Se ultrapassar 10%, revisar classificação.

Na análise 01/2026:
- Platform antes da validação do usuário: 24,1%
- Platform após correções: 2,4%

---

## 5. Tratamento de dados parciais (extrapolação)

Se o CSV de eventos cobrir menos de um mês completo:

```
count_mensal = count_periodo × (dias_mes / dias_cobertos)
```

Forma simplificada para semanas:

```
count_mensal = count_semana × 4
```

Registrar como premissa: "eventos extrapolados de N dias — premissa de período representativo".

---

## 6. Referência histórica

A classificação completa dos 435 topics de 01/2026 está em:

- `event-classification-2026-01.md`

Usar como referência inicial para períodos futuros. Topics novos que aparecerem em ciclos seguintes devem ser classificados e adicionados ao registro daquele período.

---

## 7. Manutenção

Este mapeamento deve ser atualizado quando:

- O usuário corrigir a classificação de um topic
- Um novo produto for incluído no escopo
- Um topic multi-produto mudar de composição
- A arquitetura da plataforma introduzir novos padrões de evento

Atualizações devem registrar data de validação na tabela da seção 2.
