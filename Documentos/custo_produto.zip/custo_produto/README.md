# custo_produto

Engine operacional para levantamento, validação, cálculo e publicação do custo unitário direto, indireto e total dos produtos fiscais operados pelo SaaS.

---

## Produtos no escopo

- CT-e — Conhecimento de Transporte Eletrônico
- NF-e — Nota Fiscal Eletrônica
- NFS-e — Nota Fiscal de Serviços Eletrônica
- GNRE — Guia Nacional de Recolhimento de Tributos Estaduais
- MDF-e — Manifesto Eletrônico de Documentos Fiscais

---

## Objetivo

Produzir análises de custo unitário que sejam:

- repetíveis
- auditáveis
- revisáveis por humanos

Eliminando decisões de custo baseadas em percepção informal.

---

## Estado atual

| Componente | Status |
|---|---|
| Método de custeio | definido |
| Templates de entrada e saída | estáveis |
| Regras de validação | ativas |
| Revisão humana no fluxo | incorporada |
| README e CHANGELOG | atualizados |

**Pronto para uso operacional com revisão humana.**

---

## Como usar

### 1. Iniciar análise

Fornecer ao agente:

- produto(s) no escopo
- período de análise
- volume por produto
- custos diretos conhecidos
- custos indiretos candidatos
- critério de rateio (ou usar padrão por volume)
- fonte dos dados

### 2. Fluxo de execução

```
collect-cost-data
  → calculate-unit-cost
    → reconcile-direct-vs-indirect
      → publish-cost-report
```

### 3. Revisar resultado

Antes de usar o relatório para decisão:

- executar `review-checklist.md`
- validar premissas e limitações
- classificar nível de confiança

---

## Estrutura do repositório

```
AGENTS.md                        # roteador principal do engine
README.md                        # este arquivo
CHANGELOG.md                     # histórico de mudanças

.agents/
  context/
    product-scope.md             # escopo funcional dos produtos fiscais
    costing-method.md            # método oficial de custeio

  rules/
    00-global.md                 # regras globais obrigatórias
    10-architecture.md           # arquitetura do modelo de custeio
    20-coding.md                 # padrões de implementação (quando houver código)
    30-validation.md             # regras de validação
    40-documentation.md          # regras de documentação
    50-security.md               # regras de segurança operacional
    60-delivery.md               # critérios de entrega

  skills/
    collect-cost-data.md         # estruturar dados de entrada
    calculate-unit-cost.md       # calcular custo unitário
    reconcile-direct-vs-indirect.md  # reconciliar classificação de custos
    publish-cost-report.md       # gerar relatório final
    evolve-engine-with-review.md # propor evolução do engine

  templates/
    cost-input-template.md       # template de entrada de dados
    cost-report-template.md      # template de relatório de custo
    handoff.md                   # template de handoff entre sessões
    review-checklist.md          # checklist de revisão antes de publicar

  subagents/
    fiscal-cost-analyst.md       # analista principal de custos
    data-quality-reviewer.md     # revisor de qualidade de dados
    documentation-maintainer.md  # mantenedor de documentação

  decisions/                     # decisões formais registradas
```

---

## Método de custeio

O engine usa **custeio por absorção simplificado**:

```
custo_total_unitario = custo_direto_unitario + custo_indireto_unitario
```

- **Custo direto**: atribuível por documento (ex: custo de emissão por provider)
- **Custo indireto**: compartilhado, rateado por volume total de documentos (padrão)

Ver `.agents/context/costing-method.md` para detalhes completos.

---

## Fases de operação

| Fase | Descrição |
|---|---|
| phase-0-discovery | entendimento de escopo e lacunas |
| phase-1-data-collection | coleta e organização dos dados |
| phase-2-validation | verificação de consistência e qualidade |
| phase-3-costing | cálculo de custo direto, indireto e total |
| phase-4-review | revisão metodológica e documental |
| phase-5-publication | publicação do relatório |

---

## Critério de prontidão para produção

O engine está pronto para uso quando:

- [x] método de custeio definido
- [x] templates de entrada e saída estáveis
- [x] regras de validação ativas
- [x] revisão humana incorporada no fluxo
- [x] README e CHANGELOG refletem o estado atual
