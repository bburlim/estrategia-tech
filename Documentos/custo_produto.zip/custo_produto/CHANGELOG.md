# CHANGELOG

Registro de mudanças relevantes no engine de custeio.

---

## [2026-03-27] — Estrutura inicial completa do engine

### Adicionado

- `AGENTS.md` — roteador principal do engine
- `README.md` — documentação de uso e estrutura do repositório
- `.agents/context/product-scope.md` — escopo funcional dos cinco produtos fiscais
- `.agents/context/costing-method.md` — método oficial de custeio por absorção simplificado
- `.agents/rules/00-global.md` — regras globais de comportamento dos agentes
- `.agents/rules/10-architecture.md` — arquitetura do modelo de custeio
- `.agents/rules/20-coding.md` — padrões para implementação de código no engine
- `.agents/rules/30-validation.md` — regras de validação de entrada e saída
- `.agents/rules/40-documentation.md` — regras de documentação
- `.agents/rules/50-security.md` — regras de segurança operacional
- `.agents/rules/60-delivery.md` — critérios de entrega
- `.agents/skills/collect-cost-data.md` — skill de coleta e estruturação de dados
- `.agents/skills/calculate-unit-cost.md` — skill de cálculo de custo unitário
- `.agents/skills/reconcile-direct-vs-indirect.md` — skill de reconciliação de classificação
- `.agents/skills/publish-cost-report.md` — skill de publicação de relatório
- `.agents/skills/evolve-engine-with-review.md` — skill de evolução controlada do engine
- `.agents/templates/cost-input-template.md` — template de entrada de dados
- `.agents/templates/cost-report-template.md` — template de relatório de custo
- `.agents/templates/handoff.md` — template de handoff entre sessões
- `.agents/templates/review-checklist.md` — checklist de revisão antes de publicar
- `.agents/subagents/fiscal-cost-analyst.md` — papel do analista principal de custos
- `.agents/subagents/data-quality-reviewer.md` — papel do revisor de qualidade de dados
- `.agents/subagents/documentation-maintainer.md` — papel do mantenedor de documentação
- `.agents/decisions/` — diretório para registro de decisões formais

### Estado ao final desta versão

Engine completo e pronto para uso operacional com revisão humana.
Nenhuma análise real de custo foi executada ainda.
Próximo passo: executar primeira análise com dados reais.

---

## [2026-03-30] — Primeira análise de custo executada (01/2026, cloud)

### Adicionado

- `cost-report-2026-01.md` — custo unitário de cloud por produto, período 01/2026
- `.agents/decisions/2026-01-rateio-consumo-tecnico-kb.md` — decisão formal sobre critério de rateio por consumo técnico (KB por arquivo)

### Decisões registradas

- Critério de rateio: consumo técnico (PSC = Volume × KB por arquivo)
- Tamanhos adotados: CT-e = 9 KB, GNRE = 200 KB, NFS-e = 5 KB, NF-e = 5 KB
- Custo direto excluído desta análise por decisão explícita

### Estado ao final desta versão

Primeira análise executada com sucesso. Cobre apenas componente cloud.
Custo total do produto (diretos + demais indiretos) pendente de análise complementar.

## [2026-03-30] — Revisão do método de rateio cloud + inclusão MDF-e (01/2026)

### Alterado
- `cost-report-2026-01.md` atualizado para v2.0 — método PSC substituído por multi-critério

### Adicionado
- `.agents/decisions/2026-01-rateio-multi-criterio-cloud.md` — decisão formal do critério multi-componente

### Decisões registradas
- Compute rateado por eventos processados (count)
- Storage e Networking rateados por tamanho dos eventos (bytes)
- Database e Platform rateados por volume de documentos
- MDF-e incluído no escopo com volume de 101.839 docs/mês
- Total Azure = R$ 123.500 (R$ 101.048 export + R$ 22.451 taxas/impostos, escalonados proporcionalmente)

### Impacto vs v1.0
| Produto | v1.0 | v2.0 | Δ |
|---|---|---|---|
| CT-e | R$ 0,0000736 | R$ 0,0002103 | +186% |
| GNRE | R$ 0,0016363 | R$ 0,0004825 | -71% |
| NFS-e | R$ 0,0000409 | R$ 0,0009505 | +2.224% |
| NF-e | R$ 0,0000409 | R$ 0,0000274 | -33% |
| MDF-e | — | R$ 0,0044279 | novo |

## [2026-03-30] — Validação de eventos e correção de split multi-produto (v2.1)

### Alterado
- `cost-report-2026-01.md` atualizado para v2.1
- `event-classification-2026-01.md` atualizado com % de certeza e split validado

### Correções na classificação de eventos (validadas pelo usuário)
| Event Topic | Classificação anterior | Classificação correta |
|---|---|---|
| `NOTIFICACAO_DOCS_CARGA_RECEBIDA` | Platform (50%) | Multi: CT-e + MDF-e |
| `STATUS_DOCUMENTO_CARGA_ATUALIZADO` | Platform (60%) | Multi: CT-e + NFS-e |
| `WEBHOOK_NOTIFICADO` | Platform (70%) | Multi: todos os produtos |
| `INTEGRACAO_DOCUMENTO_INICIADA` | Platform (65%) | Multi: todos os produtos |
| `TODOS_DOCUMENTOS_CARGA_PROCESSADOS` | Platform (60%) | Multi: CT-e + NFS-e |
| `CONSULTA_ITEM_LINE_HAUL_SOLICITADO` | Platform (50%) | Multi: CT-e + MDF-e |
| `HU_CONSULTADO` | NF-e (75%) | Multi: CT-e + MDF-e |
| `CONSULTA_HU_SOLICITADA` | NF-e (75%) | Multi: CT-e + MDF-e |
| `DOCUMENT_ROUTE_REDISPATCH_MELI_CONSULTADO` | NF-e (75%) | Multi: CT-e + MDF-e |
| `ROUTE_REDISPATCH_MELI_CONSULTADA` | NF-e (75%) | Multi: CT-e + MDF-e |
| `CONSULTA_ROUTE_REDISPATCH_MELI_SOLICITADA` | NF-e (75%) | Multi: CT-e + MDF-e |

### Impacto nos custos unitários
| Produto | v2.0 | v2.1 | Δ |
|---|---|---|---|
| CT-e | R$ 0,0002103 | R$ 0,0002056 | -2,2% |
| GNRE | R$ 0,0004825 | R$ 0,0003986 | -17,4% |
| NFS-e | R$ 0,0009505 | R$ 0,0007781 | -18,1% |
| NF-e | R$ 0,0000274 | R$ 0,0000287 | +4,6% |
| MDF-e | R$ 0,0044279 | R$ 0,0036633 | -17,3% |

### Platform residual
Platform passou de 24,1% para 2,4% do total de eventos após as correções.

<!-- novas entradas acima desta linha -->
